# DJZS Engine — Status Snapshot

**Snapshot date:** 2026-04-22
**Engine version:** djzs-engine-v1.0.0-alpha
**Taxonomy version:** djzs-lf-v1.2
**Test status:** 56/56 passing

## What works end-to-end (verified in this snapshot)

1. **Thesis parsing** — Zod-validated structured input, rejects hedging/questions/non-verb propositions
2. **REVIEW verdict on parse failure** — unparseable theses return structured error codes, never reach the engine, never charge
3. **Deterministic engine** — `computeVerdict()` in pure TS, reproducible hashes
4. **CLI audit** — `djzs audit <file>` runs end-to-end, emits colored terminal output
5. **Receipt generation + verification** — `djzs verify <receipt>` confirms `✓ Receipt hash valid` on clean receipts, `✗ INVALID` on tampered ones
6. **Polymarket adapter** — pulls live market state from Gamma API at audit time
7. **CoinGlass adapter** — 5 endpoints (funding, OI, liquidations, L/S ratio, combined getPerpState), preserves source metadata on every response
8. **Pyth spot adapter** — separate helper for oracle divergence reference
9. **4 shipping detectors**:
   - `X01 EXECUTION_UNBOUND` (both pillars)
   - `U03 UNFALSIFIABLE` (universal, catches missing/vacuous/tautological falsification)
   - `R01 REFLEXIVITY_RISK` (perps, uses CoinGlass liquidation cluster data)
   - `R02 FUNDING_DECAY` (perps, OI-weighted funding over hold duration)

## What is not yet built

**Remaining 20 LF codes:** S01, S02, E01, E02, E03, I01, I02, T01, T02, X02, A01, O01, U01, U02, U04, U05 — defined in the registry with weights/severities, but detector logic not implemented.

**Missing infrastructure:**
- GDELT evidence adapter (blocks E01/E02/E03)
- Irys anchoring wiring (receipts generate but don't persist to Datachain)
- API server (Cloudflare Workers wrapper around runAudit)
- x402 payment middleware
- Distribution UI (receipt gallery, share cards)

## How to use it locally

```bash
cd djzs-engine
npm install
npm test                                          # 56/56 should pass

# Prediction market audit (no API key needed for the CLI)
npx tsx cli/djzs.ts example polymarket > my-thesis.json
# edit my-thesis.json with your real thesis
npx tsx cli/djzs.ts audit my-thesis.json

# Perp audit (requires CoinGlass API key, $29/mo Hobbyist tier)
export CG_API_KEY=your-coinglass-key
npx tsx cli/djzs.ts example perp > my-perp.json
# edit my-perp.json
npx tsx cli/djzs.ts audit my-perp.json

# Verify a receipt
npx tsx cli/djzs.ts verify my-thesis.receipt.json
```

## Critical invariants (tested)

- `canonicalJSON(x) === canonicalJSON(JSON.parse(JSON.stringify(x)))` — round-trip stability
- Same inputs → same `compute_hash`
- Tampered receipt → hash verification fails
- Parse failures never reach the engine

## Next increments (in priority order)

1. Package this snapshot, run one real audit of a live trade
2. Add next batch of detectors that require NO new adapters (S01, S02, T01, A01, U01, U02, U04, U05)
3. Build GDELT adapter → unlock E01/E02/E03
4. Build O01 ORACLE_DIVERGENCE using existing CoinGlass + Pyth data
5. T02 MARKET_MOVED_PRE_CONFIRMATION (most strategically valuable remaining code)
6. Irys anchoring wiring
7. Cloudflare Workers API layer
