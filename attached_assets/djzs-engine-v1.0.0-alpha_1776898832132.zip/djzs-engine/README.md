# @djzs/engine

Deterministic audit engine for prediction markets and perpetual futures.

```
// SYS_ID: djzs-mainnet-01
// ENGINE: djzs-engine-v1.0.0-alpha
// TAXONOMY: djzs-lf-v1.2 (3/24 codes shipping)
// STATUS: FOUNDATION_COMPLETE
```

## What this is

A working skeleton of DJZS. It includes:

- **Structured thesis schema** — every audit input goes through Zod validation. Parse failures return REVIEW, never ABORT.
- **Core engine** — pure-TypeScript `computeVerdict()`. No network calls. No LLM calls. Reproducible.
- **Three fully-implemented detectors** — `X01 EXECUTION_UNBOUND`, `U03 UNFALSIFIABLE`, `R02 FUNDING_DECAY`. Reference implementations for the remaining 21 codes.
- **Two venue adapters** — Polymarket (Gamma API) and Hyperliquid (Info API + Pyth spot). Pull-on-audit, no streaming.
- **Receipt schema v2** — deterministic hashing with keccak256, evidence snapshots, conditional disclaimers.
- **CLI** — `djzs audit <thesis.json>` runs an audit from terminal against live markets.
- **Test suite** — determinism, parsing, detector correctness, receipt verification.

## What this is NOT yet

- 21 of the 24 LF codes are not yet implemented. See `TODO` in `src/codes/detectors/index.ts`.
- No GDELT evidence adapter yet — `E01/E02/E03` detectors will depend on it.
- No liquidation cluster data — `R01` detector stub only.
- No Irys anchoring wiring — receipts are generated but not yet persisted to Datachain.
- No API server — CLI only. Cloudflare Workers wrapper is a separate build.
- No x402 payment middleware wired — intended for the API layer, not CLI.

## Install

```bash
cd djzs-engine
npm install
```

## Run tests

```bash
npm test
```

## CLI usage

### Audit a thesis

Create a thesis file (see `djzs example polymarket` or `djzs example perp` for templates):

```bash
npm run cli -- example polymarket > my-thesis.json
# edit my-thesis.json with your real thesis
npm run cli -- audit my-thesis.json
```

### Verify a receipt

```bash
npm run cli -- verify my-thesis.receipt.json
```

### Example: audit a real Hyperliquid perp thesis

```bash
# Generate template
npm run cli -- example perp > btc-long.json

# Edit: adjust proposition, entry/target/stop prices, deadline
# Then:
npm run cli -- audit btc-long.json
```

The CLI will:
1. Parse and validate the thesis (parse failures return REVIEW, free).
2. Pull live Hyperliquid oracle + funding + OI for BTC-PERP.
3. Pull Pyth spot reference for divergence check.
4. Run all registered detectors.
5. Print the verdict with color-coded severity.
6. Save the receipt next to the input file.

## Exit codes

- `0` — PASS or PASS_WITH_NOTES
- `1` — ABORT or REVIEW
- `2` — Invalid CLI usage
- `3` — Fatal error

Useful for scripting: `djzs audit trade.json && execute-trade trade.json`.

## Architecture

```
┌──────────────────┐    ┌──────────────┐    ┌────────────────┐
│ Structured       │───▶│ Adapters     │───▶│ Engine         │
│ Thesis (Zod)     │    │ (pull REST)  │    │ (pure TS)      │
└──────────────────┘    └──────────────┘    └────────────────┘
                                                     │
                                                     ▼
                        ┌────────────────────────────────────┐
                        │ Detectors (X01, U03, R02, …)       │
                        │ Each returns LFTrigger | null      │
                        └────────────────────────────────────┘
                                                     │
                                                     ▼
                        ┌────────────────────────────────────┐
                        │ Verdict (PASS / PASS_WITH_NOTES /  │
                        │          ABORT / REVIEW)           │
                        └────────────────────────────────────┘
                                                     │
                                                     ▼
                        ┌────────────────────────────────────┐
                        │ Receipt (keccak256 hashed)         │
                        │ Ready for Irys anchoring           │
                        └────────────────────────────────────┘
```

## Determinism guarantee

Given identical inputs (same thesis, same adapter responses), `computeVerdict()` returns bit-identical `compute_hash`. This property is verified by the test suite.

What breaks determinism (by design):
- `audit_completed_at` timestamp (changes every run — correct).
- Adapter responses (market state changes over time — correct).

What must never break determinism:
- Detector logic producing different weights for the same inputs.
- Verdict thresholds shifting between runs.
- Code ordering affecting verdict.

The test suite covers all three.

## Next build increments

In priority order, what to ship next:

1. **GDELT evidence adapter** — unlocks `E01`, `E02`, `E03` detectors
2. **Remaining 21 detectors** — pattern follows `X01_Detector`, `U03_Detector`, `R02_Detector`
3. **Irys anchoring wiring** — `anchorReceipt(receipt)` that writes to Datachain and populates `anchored_at` + `irys_tx_id`
4. **Hyperliquid orderbook depth** — enables `R01 REFLEXIVITY_RISK` precise detection
5. **API server** — Hono or similar on Cloudflare Workers, wraps `runAudit()` behind x402

Each is a separate session. Do not build all at once.
