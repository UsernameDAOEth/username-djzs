#!/usr/bin/env node
// cli/djzs.ts
// DJZS command-line auditor. Runs against live markets from the terminal.
//
// Usage:
//   djzs audit <thesis.json>       — audit a structured thesis file
//   djzs example polymarket        — print example Polymarket thesis
//   djzs example perp              — print example perp thesis
//   djzs verify <receipt.json>     — verify a receipt's hash
//   djzs version                   — print engine version

import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { resolve } from "node:path";
import { runAudit, type AuditContext } from "../src/engine/audit.js";
import { CoinGlassAdapter } from "../src/adapters/coinglass.js";
import {
  verifyReceiptHash,
  type DJZSReceipt,
} from "../src/receipts/schema.js";
import {
  ENGINE_VERSION,
  TAXONOMY_VERSION,
  POLICY_VERSION,
} from "../src/engine/core.js";

// ANSI color codes — match Terminal Brutalism aesthetic
const C = {
  reset: "\x1b[0m",
  dim: "\x1b[2m",
  bold: "\x1b[1m",
  green: "\x1b[38;5;46m", // #00FF41 terminal green approx
  amber: "\x1b[38;5;214m",
  red: "\x1b[38;5;196m",
  cyan: "\x1b[38;5;51m",
  yellow: "\x1b[38;5;226m",
};

function banner() {
  console.log(
    `${C.dim}// SYS_ID: djzs-mainnet-01${C.reset}\n` +
      `${C.dim}// ENGINE: ${ENGINE_VERSION}${C.reset}\n` +
      `${C.dim}// TAXONOMY: ${TAXONOMY_VERSION}${C.reset}\n` +
      `${C.dim}// POLICY: ${POLICY_VERSION}${C.reset}\n`
  );
}

function usage(): void {
  banner();
  console.log(`${C.bold}DJZS audit CLI${C.reset}\n`);
  console.log("Commands:");
  console.log("  djzs audit <thesis.json>       Audit a structured thesis");
  console.log("  djzs example polymarket        Print example PM thesis");
  console.log("  djzs example perp              Print example perp thesis");
  console.log("  djzs verify <receipt.json>     Verify receipt hash");
  console.log("  djzs version                   Print engine version\n");
}

// ============================================================================
// audit command
// ============================================================================

async function cmdAudit(path: string): Promise<number> {
  const resolved = resolve(path);
  if (!existsSync(resolved)) {
    console.error(`${C.red}File not found: ${resolved}${C.reset}`);
    return 2;
  }

  let raw: unknown;
  try {
    raw = JSON.parse(readFileSync(resolved, "utf-8"));
  } catch (err) {
    console.error(`${C.red}Invalid JSON: ${err}${C.reset}`);
    return 2;
  }

  banner();
  console.log(`${C.dim}// Auditing ${resolved}${C.reset}\n`);

  // Wire CoinGlass from env if available (required for perp audits)
  const ctx: AuditContext = {};
  const cgKey = process.env.CG_API_KEY;
  if (cgKey && cgKey.length >= 8) {
    try {
      ctx.coinglass = new CoinGlassAdapter({ apiKey: cgKey });
      console.log(`${C.dim}// CoinGlass adapter enabled${C.reset}`);
    } catch (err) {
      console.warn(`${C.amber}// CoinGlass init failed: ${err}${C.reset}`);
    }
  } else {
    console.log(
      `${C.dim}// No CG_API_KEY set. Perp audits will return an error.${C.reset}`
    );
  }
  console.log("");

  const result = await runAudit(raw, ctx);

  if (!result.success) {
    console.log(`${C.yellow}╔══ VERDICT: REVIEW ══╗${C.reset}\n`);
    console.log(`${C.yellow}Input did not parse. Fix errors below.${C.reset}\n`);
    for (const err of result.parse_errors ?? []) {
      console.log(`  ${C.red}[${err.code}]${C.reset} ${C.bold}${err.path}${C.reset}`);
      console.log(`    ${err.message}\n`);
    }
    console.log(
      `${C.dim}No engine run, no payment. Fix and resubmit.${C.reset}\n`
    );
    return 1;
  }

  const receipt = result.receipt!;
  printReceipt(receipt);

  // Save receipt next to input
  const outPath = resolved.replace(/\.json$/, ".receipt.json");
  writeFileSync(outPath, JSON.stringify(receipt, null, 2));
  console.log(`\n${C.dim}// Receipt saved: ${outPath}${C.reset}`);

  // Exit code reflects verdict — useful for scripting
  if (receipt.verdict === "ABORT") return 1;
  return 0;
}

function printReceipt(receipt: DJZSReceipt): void {
  const verdictColor =
    receipt.verdict === "PASS"
      ? C.green
      : receipt.verdict === "PASS_WITH_NOTES"
        ? C.amber
        : receipt.verdict === "ABORT"
          ? C.red
          : C.yellow;

  console.log(`${verdictColor}${C.bold}╔══════════════════════════════════════════╗${C.reset}`);
  console.log(
    `${verdictColor}${C.bold}║ VERDICT: ${receipt.verdict.padEnd(32)}║${C.reset}`
  );
  console.log(`${verdictColor}${C.bold}╚══════════════════════════════════════════╝${C.reset}\n`);

  console.log(`${C.cyan}Risk score:${C.reset}    ${receipt.risk_score} / ${receipt.risk_ceiling}`);
  console.log(`${C.cyan}Receipt ID:${C.reset}    ${receipt.receipt_id}`);
  console.log(`${C.cyan}Keccak:${C.reset}        ${receipt.keccak_proof}`);
  console.log(`${C.cyan}Computed at:${C.reset}   ${receipt.audit_completed_at}`);
  console.log(`${C.cyan}Venue:${C.reset}         ${receipt.thesis.market.venue}`);
  console.log("");

  if (receipt.triggered_codes.length === 0) {
    console.log(`${C.green}No codes triggered.${C.reset}\n`);
  } else {
    console.log(`${C.bold}Triggered codes:${C.reset}\n`);
    for (const t of receipt.triggered_codes) {
      const sevColor =
        t.severity === "critical"
          ? C.red
          : t.severity === "high"
            ? C.amber
            : t.severity === "medium"
              ? C.yellow
              : C.dim;
      console.log(
        `  ${sevColor}${C.bold}${t.code}${C.reset} ${t.name.padEnd(32)} ${sevColor}${t.severity.toUpperCase().padEnd(8)}${C.reset} ${C.dim}(-${t.weight})${C.reset}`
      );
      console.log(`    ${C.dim}${t.reason}${C.reset}\n`);
    }
  }

  if (receipt.remediation.length > 0) {
    console.log(`${C.bold}Remediation:${C.reset}\n`);
    for (const r of receipt.remediation) {
      console.log(`  ${C.cyan}[${r.code}]${C.reset} ${C.bold}${r.field}${C.reset}`);
      console.log(`    ${r.required_change}`);
      if (r.example) console.log(`    ${C.dim}Example: ${r.example}${C.reset}`);
      console.log("");
    }
  }

  console.log(`${C.dim}─────────────────────────────────────────────${C.reset}`);
  console.log(`${C.dim}Disclaimer:${C.reset}`);
  console.log(`${C.dim}${receipt.disclaimers.pass_does_not_guarantee_resolution}${C.reset}`);
  if (receipt.disclaimers.perp_pre_trade_only) {
    console.log(`\n${C.dim}${receipt.disclaimers.perp_pre_trade_only}${C.reset}`);
  }
  if (receipt.disclaimers.mnpi_recorded) {
    console.log(`\n${C.dim}${receipt.disclaimers.mnpi_recorded}${C.reset}`);
  }
}

// ============================================================================
// example command
// ============================================================================

function cmdExample(kind: string): number {
  const now = new Date();
  const deadline = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

  if (kind === "polymarket") {
    const example = {
      schema_version: "thesis-v1",
      submitted_at: now.toISOString(),
      proposition: "The Fed cuts rates by at least 25bps at the May 2026 FOMC meeting.",
      target_outcome: "Polymarket market 'Fed rate cut May 2026' resolves YES",
      deadline: deadline.toISOString(),
      market: {
        venue: "polymarket",
        market_id: "0x...",
        market_url: "https://polymarket.com/event/fed-decision-may-2026",
        resolution_source_url: "https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm",
      },
      proposed_trade: {
        direction: "yes",
        size_usdc: 500,
        confidence: 0.65,
      },
      information_source_type: "public",
      key_assumptions: [
        "Fed maintains dovish guidance from April meeting",
        "No upside surprise in April CPI print",
      ],
      evidence_claims: [
        {
          claim_text: "Fed funds futures pricing ~70% probability of 25bp cut",
          source_url: "https://www.cmegroup.com/markets/interest-rates/cme-fedwatch-tool.html",
          is_load_bearing: true,
        },
      ],
      falsification_condition:
        "If the April CPI print comes in above 3.2% year-over-year, the thesis is invalidated.",
    };
    console.log(JSON.stringify(example, null, 2));
    return 0;
  }

  if (kind === "perp") {
    const example = {
      schema_version: "thesis-v1",
      submitted_at: now.toISOString(),
      proposition:
        "BTC-PERP closes above $110,000 within 7 days based on institutional accumulation signals.",
      target_outcome: "BTC-PERP mark price above 110000 at deadline",
      deadline: deadline.toISOString(),
      market: {
        venue: "hyperliquid",
        market_id: "BTC",
        market_url: "https://app.hyperliquid.xyz/trade/BTC",
      },
      proposed_trade: {
        direction: "long",
        size_usdc: 2000,
        confidence: 0.55,
        entry_price: 103500,
        target_price: 110000,
        stop_price: 100000,
        leverage: 3,
      },
      perp_context: {
        pair: "BTC-PERP",
        current_funding_rate_8h: 0.0001,
        oracle_price: 103500,
      },
      information_source_type: "public",
      key_assumptions: [
        "ETF flows remain positive",
        "No major macro shock before deadline",
      ],
      evidence_claims: [],
      falsification_condition:
        "If BTC closes below $100,000 for two consecutive daily candles, thesis invalidated.",
      _note:
        "Market state (funding, OI, liquidation clusters) is pulled live from CoinGlass at audit time. perp_context values here are fallbacks if CoinGlass is unreachable. Set CG_API_KEY env var before running `djzs audit`.",
    };
    console.log(JSON.stringify(example, null, 2));
    return 0;
  }

  console.error(`${C.red}Unknown example: ${kind}. Use 'polymarket' or 'perp'.${C.reset}`);
  return 2;
}

// ============================================================================
// verify command
// ============================================================================

function cmdVerify(path: string): number {
  const resolved = resolve(path);
  if (!existsSync(resolved)) {
    console.error(`${C.red}File not found: ${resolved}${C.reset}`);
    return 2;
  }

  let receipt: DJZSReceipt;
  try {
    receipt = JSON.parse(readFileSync(resolved, "utf-8"));
  } catch (err) {
    console.error(`${C.red}Invalid JSON: ${err}${C.reset}`);
    return 2;
  }

  banner();
  const result = verifyReceiptHash(receipt);
  if (result.valid) {
    console.log(`${C.green}${C.bold}✓ Receipt hash valid${C.reset}`);
    console.log(`${C.dim}  Expected: ${result.expected}${C.reset}`);
    console.log(`${C.dim}  Actual:   ${result.actual}${C.reset}`);
    return 0;
  } else {
    console.log(`${C.red}${C.bold}✗ Receipt hash INVALID${C.reset}`);
    console.log(`${C.dim}  Expected: ${result.expected}${C.reset}`);
    console.log(`${C.dim}  Actual:   ${result.actual}${C.reset}`);
    return 1;
  }
}

// ============================================================================
// main
// ============================================================================

async function main(): Promise<void> {
  const [cmd, arg] = process.argv.slice(2);

  let code = 0;
  switch (cmd) {
    case "audit":
      if (!arg) {
        console.error(`${C.red}Usage: djzs audit <thesis.json>${C.reset}`);
        code = 2;
      } else {
        code = await cmdAudit(arg);
      }
      break;
    case "example":
      code = cmdExample(arg ?? "polymarket");
      break;
    case "verify":
      if (!arg) {
        console.error(`${C.red}Usage: djzs verify <receipt.json>${C.reset}`);
        code = 2;
      } else {
        code = cmdVerify(arg);
      }
      break;
    case "version":
      banner();
      code = 0;
      break;
    case undefined:
    case "help":
    case "--help":
    case "-h":
      usage();
      code = 0;
      break;
    default:
      console.error(`${C.red}Unknown command: ${cmd}${C.reset}`);
      usage();
      code = 2;
  }

  process.exit(code);
}

main().catch((err) => {
  console.error(`${C.red}Fatal error:${C.reset}`, err);
  process.exit(3);
});
