// src/adapters/coinglass.ts
// CoinGlass Crypto API adapter — derivatives aggregation layer.
//
// Replaces venue-specific adapters (Hyperliquid, etc.) with a normalized
// multi-venue data layer. Covers OI, funding, liquidations, long/short,
// and orderbook data across 30+ exchanges.
//
// Docs: https://docs.coinglass.com
// Base URL: https://open-api-v4.coinglass.com
// Auth: CG-API-KEY header
//
// Source metadata preservation is MANDATORY. Every response is tagged with
// provider/endpoint/scope/timestamp/hash so receipts remain defensible even
// when CoinGlass's aggregation changes.

import type { PerpStateInput, MarketStateInput } from "../engine/core.js";
import { hashInput } from "../engine/core.js";

const DEFAULT_BASE_URL = "https://open-api-v4.coinglass.com";

// ============================================================================
// Source metadata — preserved on every response
// ============================================================================

export interface SourceMetadata {
  provider: "coinglass";
  endpoint: string;
  exchange_scope: string[] | "aggregated";
  fetched_at: string;
  response_hash: string;
  freshness_window_seconds: number;
  api_version: "v4";
}

export interface CoinGlassResponse<T> {
  data: T;
  source: SourceMetadata;
}

// ============================================================================
// Typed response shapes
// ============================================================================

/** Per-exchange funding rate for a symbol. */
export interface FundingRateByExchange {
  exchange: string;
  symbol: string;
  funding_rate: number; // As decimal (0.0001 = 0.01%)
  next_funding_time: string | null;
  interval_hours: number; // Typically 8, some venues differ
}

/** Per-exchange open interest for a symbol. */
export interface OpenInterestByExchange {
  exchange: string;
  symbol: string;
  open_interest_usd: number;
  open_interest_base: number; // Contracts / tokens
}

/** Aggregated liquidation data for a time window. */
export interface LiquidationSummary {
  symbol: string;
  window_hours: number;
  total_liquidations_usd: number;
  long_liquidations_usd: number;
  short_liquidations_usd: number;
  liquidation_price_clusters: Array<{
    price: number;
    cumulative_usd: number;
  }>;
}

/** Long/short ratio for a symbol. */
export interface LongShortRatio {
  exchange: string;
  symbol: string;
  long_ratio: number; // 0.0 - 1.0
  short_ratio: number; // 0.0 - 1.0
  ratio_type:
    | "taker_buy_sell"
    | "top_trader_position"
    | "top_trader_account";
}

// ============================================================================
// Adapter
// ============================================================================

export interface CoinGlassAdapterOptions {
  apiKey: string;
  baseUrl?: string;
  cacheBucketSeconds?: number;
  fetchImpl?: typeof fetch;
  requestTimeoutMs?: number;
}

export class CoinGlassAdapter {
  private cache = new Map<
    string,
    { data: CoinGlassResponse<unknown>; ts: number }
  >();
  private readonly apiKey: string;
  private readonly baseUrl: string;
  private readonly cacheBucketSeconds: number;
  private readonly fetchImpl: typeof fetch;
  private readonly requestTimeoutMs: number;

  constructor(opts: CoinGlassAdapterOptions) {
    if (!opts.apiKey || opts.apiKey.length < 8) {
      throw new Error(
        "CoinGlassAdapter: apiKey is required (min 8 chars). " +
          "Get one at https://www.coinglass.com/developer"
      );
    }
    this.apiKey = opts.apiKey;
    this.baseUrl = opts.baseUrl ?? DEFAULT_BASE_URL;
    this.cacheBucketSeconds = opts.cacheBucketSeconds ?? 60;
    this.fetchImpl = opts.fetchImpl ?? fetch;
    this.requestTimeoutMs = opts.requestTimeoutMs ?? 5000;
  }

  // ==========================================================================
  // Low-level request
  // ==========================================================================

  private async request<T>(
    endpoint: string,
    params: Record<string, string | number>,
    opts: { scope: string[] | "aggregated" } = { scope: "aggregated" }
  ): Promise<CoinGlassResponse<T> | null> {
    const query = new URLSearchParams(
      Object.entries(params).map(([k, v]) => [k, String(v)])
    ).toString();
    const cacheKey = `${endpoint}?${query}`;

    const cached = this.getCached<T>(cacheKey);
    if (cached) return cached;

    try {
      const url = `${this.baseUrl}${endpoint}?${query}`;
      const res = await this.fetchImpl(url, {
        headers: {
          "CG-API-KEY": this.apiKey,
          Accept: "application/json",
        },
        signal: AbortSignal.timeout(this.requestTimeoutMs),
      });
      if (!res.ok) {
        console.warn(`CoinGlass ${endpoint} ${res.status}`);
        return null;
      }
      const raw = (await res.json()) as any;

      // CoinGlass v4 wraps responses: { code, msg, data }
      if (raw.code !== undefined && raw.code !== 0 && raw.code !== "0") {
        console.warn(`CoinGlass ${endpoint} code=${raw.code} msg=${raw.msg}`);
        return null;
      }
      const data = (raw.data ?? raw) as T;

      const fetched_at = new Date().toISOString();
      const response_hash = hashInput(data);

      const wrapped: CoinGlassResponse<T> = {
        data,
        source: {
          provider: "coinglass",
          endpoint,
          exchange_scope: opts.scope,
          fetched_at,
          response_hash,
          freshness_window_seconds: this.cacheBucketSeconds,
          api_version: "v4",
        },
      };

      this.setCached(cacheKey, wrapped);
      return wrapped;
    } catch (err) {
      console.warn(`CoinGlass ${endpoint} fetch failed:`, err);
      return null;
    }
  }

  // ==========================================================================
  // Funding rate
  // ==========================================================================

  /**
   * Get funding rates for a symbol across all supported exchanges.
   * Useful for: identifying funding skew, picking reference rate, finding
   * the venue with the least punitive funding for a directional trade.
   */
  async getFundingRateByExchange(
    symbol: string
  ): Promise<CoinGlassResponse<FundingRateByExchange[]> | null> {
    const resp = await this.request<any>(
      "/api/futures/fundingRate/exchange-list",
      { symbol }
    );
    if (!resp) return null;

    const normalized = normalizeFundingList(resp.data, symbol);
    return { data: normalized, source: resp.source };
  }

  // ==========================================================================
  // Open interest
  // ==========================================================================

  /**
   * Get open interest across exchanges.
   * Useful for: crowding analysis, leverage imbalance, OI spike detection.
   */
  async getOpenInterestByExchange(
    symbol: string
  ): Promise<CoinGlassResponse<OpenInterestByExchange[]> | null> {
    const resp = await this.request<any>(
      "/api/futures/openInterest/exchange-list",
      { symbol }
    );
    if (!resp) return null;

    const normalized = normalizeOIList(resp.data, symbol);
    return { data: normalized, source: resp.source };
  }

  // ==========================================================================
  // Liquidation data
  // ==========================================================================

  /**
   * Get aggregated liquidation data over the last N hours for a symbol.
   * Feeds R01 REFLEXIVITY_RISK directly: the cluster list shows where
   * liquidations have historically concentrated.
   */
  async getLiquidations(
    symbol: string,
    interval: "h1" | "h4" | "h12" | "h24" = "h24"
  ): Promise<CoinGlassResponse<LiquidationSummary> | null> {
    const resp = await this.request<any>(
      "/api/futures/liquidation/aggregated-history",
      { symbol, interval, limit: 100 }
    );
    if (!resp) return null;

    const normalized = normalizeLiquidationSummary(resp.data, symbol, interval);
    return { data: normalized, source: resp.source };
  }

  // ==========================================================================
  // Long/short ratio
  // ==========================================================================

  /**
   * Taker buy/sell long-short ratio — crowding signal.
   */
  async getLongShortRatio(
    symbol: string,
    exchange = "Binance"
  ): Promise<CoinGlassResponse<LongShortRatio> | null> {
    const resp = await this.request<any>(
      "/api/futures/longShortRatio",
      { symbol, exchange, interval: "h1" },
      { scope: [exchange] }
    );
    if (!resp) return null;

    const normalized = normalizeLongShortRatio(resp.data, symbol, exchange);
    return { data: normalized, source: resp.source };
  }

  // ==========================================================================
  // Higher-level: build engine inputs
  // ==========================================================================

  /**
   * Build PerpStateInput for the engine from CoinGlass aggregated data.
   *
   * Strategy:
   *  - Oracle price: not directly provided by CoinGlass; the engine's consumer
   *    should pair this with a separate spot reference (Pyth) if needed.
   *    For v1 we'll use aggregated mark-adjacent pricing from funding data
   *    where available, or omit.
   *  - Funding: aggregated OI-weighted mean across exchanges.
   *  - OI: total aggregated open interest USD.
   *  - Liquidation clusters: from liquidation-aggregated-history.
   */
  async getPerpState(
    symbol: string,
    opts: { preferredExchange?: string } = {}
  ): Promise<{
    state: PerpStateInput;
    sources: SourceMetadata[];
  } | null> {
    const [fundingResp, oiResp, liqResp] = await Promise.all([
      this.getFundingRateByExchange(symbol),
      this.getOpenInterestByExchange(symbol),
      this.getLiquidations(symbol, "h24"),
    ]);

    if (!fundingResp || !oiResp) {
      // OI + funding are required; liquidations are optional
      return null;
    }

    const sources: SourceMetadata[] = [
      fundingResp.source,
      oiResp.source,
    ];
    if (liqResp) sources.push(liqResp.source);

    // Pick funding rate: preferred exchange if specified, else OI-weighted mean
    let fundingRate8h: number;
    if (opts.preferredExchange) {
      const specific = fundingResp.data.find(
        (f) => f.exchange.toLowerCase() === opts.preferredExchange!.toLowerCase()
      );
      fundingRate8h = specific?.funding_rate ?? 0;
    } else {
      fundingRate8h = oiWeightedFunding(fundingResp.data, oiResp.data);
    }

    // Total OI
    const totalOI = oiResp.data.reduce(
      (sum, e) => sum + e.open_interest_usd,
      0
    );

    // Nearest liquidation cluster — derived from CoinGlass liquidation map
    // This is what makes R01 actually work (was a heuristic before)
    const nearestCluster = liqResp
      ? nearestLiquidationCluster(liqResp.data)
      : undefined;

    return {
      state: {
        oracle_price: 0, // Filled by caller from spot adapter if needed
        spot_reference_price: undefined,
        current_funding_rate_8h: fundingRate8h,
        open_interest_usd: totalOI,
        nearest_liquidation_cluster: nearestCluster,
      },
      sources,
    };
  }

  // ==========================================================================
  // Caching
  // ==========================================================================

  private getCached<T>(key: string): CoinGlassResponse<T> | null {
    const entry = this.cache.get(key);
    if (!entry) return null;
    const ageSeconds = (Date.now() - entry.ts) / 1000;
    if (ageSeconds > this.cacheBucketSeconds) {
      this.cache.delete(key);
      return null;
    }
    return entry.data as CoinGlassResponse<T>;
  }

  private setCached<T>(key: string, data: CoinGlassResponse<T>): void {
    this.cache.set(key, { data, ts: Date.now() });
  }
}

// ============================================================================
// Normalizers — CoinGlass returns loosely-typed JSON; pin types here
// ============================================================================

function normalizeFundingList(
  raw: unknown,
  symbol: string
): FundingRateByExchange[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((r: any): FundingRateByExchange | null => {
      if (!r || typeof r !== "object") return null;
      const exchange = String(r.exchange ?? r.exchangeName ?? "");
      const rate = parseFloat(r.fundingRate ?? r.funding_rate ?? "0");
      if (!exchange || !Number.isFinite(rate)) return null;
      return {
        exchange,
        symbol,
        funding_rate: rate,
        next_funding_time: (r.nextFundingTime ?? null) as string | null,
        interval_hours: Number(r.fundingInterval ?? 8),
      };
    })
    .filter((x): x is FundingRateByExchange => x !== null);
}

function normalizeOIList(
  raw: unknown,
  symbol: string
): OpenInterestByExchange[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((r: any): OpenInterestByExchange | null => {
      if (!r || typeof r !== "object") return null;
      const exchange = String(r.exchange ?? r.exchangeName ?? "");
      const oiUsd = parseFloat(
        r.openInterestUsd ?? r.openInterest ?? "0"
      );
      if (!exchange || !Number.isFinite(oiUsd)) return null;
      return {
        exchange,
        symbol,
        open_interest_usd: oiUsd,
        open_interest_base: parseFloat(
          r.openInterestBase ?? r.openInterestQuantity ?? "0"
        ),
      };
    })
    .filter((x): x is OpenInterestByExchange => x !== null);
}

function normalizeLiquidationSummary(
  raw: any,
  symbol: string,
  interval: string
): LiquidationSummary {
  const windowHours =
    interval === "h1" ? 1 : interval === "h4" ? 4 : interval === "h12" ? 12 : 24;

  // CoinGlass returns varied shapes; support both object and array
  const long = parseFloat(raw?.longLiquidationUsd ?? "0");
  const short = parseFloat(raw?.shortLiquidationUsd ?? "0");

  // Cluster data: walk the liquidationMap if present
  const clusters: Array<{ price: number; cumulative_usd: number }> = [];
  const rawClusters = raw?.liquidationMap ?? raw?.liquidations ?? [];
  if (Array.isArray(rawClusters)) {
    for (const c of rawClusters) {
      const price = parseFloat(c?.price ?? "0");
      const usd = parseFloat(c?.liquidationUsd ?? c?.amount ?? "0");
      if (Number.isFinite(price) && Number.isFinite(usd) && price > 0) {
        clusters.push({ price, cumulative_usd: usd });
      }
    }
  }
  clusters.sort((a, b) => b.cumulative_usd - a.cumulative_usd);

  return {
    symbol,
    window_hours: windowHours,
    total_liquidations_usd: long + short,
    long_liquidations_usd: long,
    short_liquidations_usd: short,
    liquidation_price_clusters: clusters.slice(0, 20),
  };
}

function normalizeLongShortRatio(
  raw: any,
  symbol: string,
  exchange: string
): LongShortRatio {
  const long = parseFloat(raw?.longRatio ?? raw?.longAccount ?? "0.5");
  const short = parseFloat(raw?.shortRatio ?? raw?.shortAccount ?? "0.5");
  return {
    exchange,
    symbol,
    long_ratio: long,
    short_ratio: short,
    ratio_type: "taker_buy_sell",
  };
}

// ============================================================================
// Helpers
// ============================================================================

/**
 * OI-weighted mean funding rate. More faithful than a simple average because
 * it reflects where the actual leverage is concentrated.
 */
function oiWeightedFunding(
  funding: FundingRateByExchange[],
  oi: OpenInterestByExchange[]
): number {
  const oiByExchange = new Map(oi.map((e) => [e.exchange, e.open_interest_usd]));
  let weightedSum = 0;
  let totalWeight = 0;
  for (const f of funding) {
    const weight = oiByExchange.get(f.exchange) ?? 0;
    weightedSum += f.funding_rate * weight;
    totalWeight += weight;
  }
  if (totalWeight === 0) {
    // Fallback to simple mean if OI data missing
    if (funding.length === 0) return 0;
    return (
      funding.reduce((s, f) => s + f.funding_rate, 0) / funding.length
    );
  }
  return weightedSum / totalWeight;
}

/**
 * Find the single largest liquidation cluster.
 * This is what R01 consumes directly.
 */
function nearestLiquidationCluster(
  summary: LiquidationSummary
): PerpStateInput["nearest_liquidation_cluster"] | undefined {
  if (summary.liquidation_price_clusters.length === 0) return undefined;
  const largest = summary.liquidation_price_clusters[0];
  return {
    price: largest.price,
    distance_pct: 0, // Caller must compute against current price
    upstream_depth_usd: 0, // Requires orderbook query
    at_cluster_depth_usd: largest.cumulative_usd,
  };
}
