// src/adapters/polymarket.ts
// Polymarket Gamma API adapter. Pull-on-audit only. No streaming.
//
// Public API — no auth required. Generous rate limits for REST.
// Docs: https://docs.polymarket.com

import type { MarketStateInput } from "../engine/core.js";
import { hashInput } from "../engine/core.js";

const GAMMA_API = "https://gamma-api.polymarket.com";
const CLOB_API = "https://clob.polymarket.com";

export interface PolymarketMarket {
  id: string;
  question: string;
  slug: string;
  end_date_iso: string | null;
  resolution_source: string | null;
  volume_24hr: number | null;
  liquidity: number | null;
  outcomes: string[];
  outcome_prices: number[];
}

export interface PolymarketAdapterOptions {
  cacheBucketSeconds?: number; // Default 300 (5 minutes)
  fetchImpl?: typeof fetch;
}

export class PolymarketAdapter {
  private cache = new Map<string, { data: unknown; ts: number }>();
  private readonly cacheBucketSeconds: number;
  private readonly fetchImpl: typeof fetch;

  constructor(opts: PolymarketAdapterOptions = {}) {
    this.cacheBucketSeconds = opts.cacheBucketSeconds ?? 300;
    this.fetchImpl = opts.fetchImpl ?? fetch;
  }

  /**
   * Extract market ID or slug from a Polymarket URL.
   * Accepts:
   *   https://polymarket.com/event/<slug>
   *   https://polymarket.com/market/<slug>
   *   https://polymarket.com/event/<slug>/<market-slug>
   */
  static parseMarketUrl(url: string): { slug: string } | null {
    try {
      const u = new URL(url);
      if (!u.hostname.includes("polymarket.com")) return null;
      const parts = u.pathname.split("/").filter(Boolean);
      // /event/<slug> or /market/<slug>
      if (parts.length >= 2 && (parts[0] === "event" || parts[0] === "market")) {
        // Prefer the deeper slug if present
        return { slug: parts[parts.length - 1] };
      }
      return null;
    } catch {
      return null;
    }
  }

  /**
   * Fetch market metadata by slug.
   * Returns null if not found or unreachable.
   */
  async fetchMarketBySlug(slug: string): Promise<PolymarketMarket | null> {
    const cached = this.getCached<PolymarketMarket>(`market:${slug}`);
    if (cached) return cached;

    try {
      const url = `${GAMMA_API}/markets?slug=${encodeURIComponent(slug)}`;
      const res = await this.fetchImpl(url, {
        headers: { Accept: "application/json" },
      });
      if (!res.ok) {
        console.warn(`Polymarket fetch ${res.status} for slug=${slug}`);
        return null;
      }
      const raw = (await res.json()) as unknown;
      const markets = Array.isArray(raw) ? raw : [];
      if (markets.length === 0) return null;

      const m = markets[0] as Record<string, unknown>;
      const market: PolymarketMarket = {
        id: String(m.id ?? ""),
        question: String(m.question ?? ""),
        slug: String(m.slug ?? slug),
        end_date_iso: (m.endDateIso as string | null) ?? (m.end_date_iso as string | null) ?? null,
        resolution_source:
          (m.resolutionSource as string | null) ?? (m.resolution_source as string | null) ?? null,
        volume_24hr: parseNumOrNull(m.volume24hr ?? m.volume_24hr),
        liquidity: parseNumOrNull(m.liquidity),
        outcomes: parseStringArray(m.outcomes),
        outcome_prices: parseNumberArray(m.outcomePrices ?? m.outcome_prices),
      };
      this.setCached(`market:${slug}`, market);
      return market;
    } catch (err) {
      console.warn("Polymarket fetch failed:", err);
      return null;
    }
  }

  /**
   * Get market state for the engine input.
   * Returns null if the market cannot be fetched.
   */
  async getMarketState(slug: string): Promise<MarketStateInput | null> {
    const market = await this.fetchMarketBySlug(slug);
    if (!market) return null;

    // Use the "YES" price as current price (outcome_prices[0])
    const currentPrice =
      market.outcome_prices && market.outcome_prices.length > 0
        ? market.outcome_prices[0]
        : 0.5; // Fallback to midpoint

    return {
      current_price: currentPrice,
      liquidity_depth_usdc: market.liquidity ?? undefined,
      volume_24h_usdc: market.volume_24hr ?? undefined,
      spread_bps: undefined, // Would require orderbook fetch; deferred
      fetched_at: new Date().toISOString(),
      source_response_hash: hashInput(market),
    };
  }

  /**
   * Check if the resolution source URL is reachable.
   */
  async checkResolutionSource(
    url: string | null
  ): Promise<{
    url: string | null;
    reachable: boolean;
    returned_data: boolean;
  }> {
    if (!url) {
      return { url: null, reachable: false, returned_data: false };
    }
    try {
      const res = await this.fetchImpl(url, {
        method: "HEAD",
        signal: AbortSignal.timeout(3000),
      });
      return {
        url,
        reachable: res.ok || res.status < 500,
        returned_data: res.ok,
      };
    } catch {
      return { url, reachable: false, returned_data: false };
    }
  }

  // ==========================================================================
  // Caching
  // ==========================================================================

  private getCached<T>(key: string): T | null {
    const entry = this.cache.get(key);
    if (!entry) return null;
    const ageSeconds = (Date.now() - entry.ts) / 1000;
    if (ageSeconds > this.cacheBucketSeconds) {
      this.cache.delete(key);
      return null;
    }
    return entry.data as T;
  }

  private setCached<T>(key: string, data: T): void {
    this.cache.set(key, { data, ts: Date.now() });
  }
}

// ============================================================================
// Parsing helpers — Polymarket API returns mixed types
// ============================================================================

function parseNumOrNull(v: unknown): number | null {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string") {
    const n = Number.parseFloat(v);
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

function parseStringArray(v: unknown): string[] {
  if (Array.isArray(v)) return v.map(String);
  if (typeof v === "string") {
    try {
      const parsed = JSON.parse(v);
      return Array.isArray(parsed) ? parsed.map(String) : [];
    } catch {
      return [];
    }
  }
  return [];
}

function parseNumberArray(v: unknown): number[] {
  if (Array.isArray(v)) {
    return v.map((x) => parseNumOrNull(x) ?? 0);
  }
  if (typeof v === "string") {
    try {
      const parsed = JSON.parse(v);
      return Array.isArray(parsed)
        ? parsed.map((x) => parseNumOrNull(x) ?? 0)
        : [];
    } catch {
      return [];
    }
  }
  return [];
}
