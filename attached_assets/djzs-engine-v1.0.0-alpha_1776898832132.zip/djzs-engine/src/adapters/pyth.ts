// src/adapters/pyth.ts
// Minimal Pyth spot price helper. Stays because CoinGlass does not provide
// oracle-grade spot references — we need this for O01 divergence detection.

import type { SourceMetadata } from "./coinglass.js";
import { hashInput } from "../engine/core.js";

const PYTH_API = "https://hermes.pyth.network/v2/updates/price/latest";

// Pyth price feed IDs — extend as needed
// Source: https://pyth.network/developers/price-feed-ids
export const PYTH_PRICE_IDS: Record<string, string> = {
  BTC: "e62df6c8b4a85fe1a67db44dc12de5db330f7ac66b72dc658afedf0f4a415b43",
  ETH: "ff61491a931112ddf1bd8147cd1b641375f79f5825126d665480874634fd0ace",
  SOL: "ef0d8b6fda2ceba41da15d4095d1da392a0d2f8ed0c6c7bc0f4cfac8c280b56d",
  AVAX: "93da3352f9f1d105fdfe4971cfa80e9dd777bfc5d0f683ebb6e1294b92137bb7",
  ARB: "3fa4252848f9f0a1480be62745a4629d9eb1322aebab8a791e344b3b9c1adcf5",
  DOGE: "dcef50dd0a4cd2dcc17e45df1676dcb336a11a61c69df7a0299b0150c672d25c",
  LINK: "8ac0c70fff57e9aefdf5edf44b51d62c2d433653cbb2cf5cc06bb115af04d221",
};

export interface PythSpotResult {
  symbol: string;
  price: number;
  timestamp: string;
  source: {
    provider: "pyth";
    feed_id: string;
    fetched_at: string;
    response_hash: string;
  };
}

export interface PythAdapterOptions {
  fetchImpl?: typeof fetch;
  requestTimeoutMs?: number;
}

export class PythSpotAdapter {
  private readonly fetchImpl: typeof fetch;
  private readonly requestTimeoutMs: number;
  private cache = new Map<string, { data: PythSpotResult; ts: number }>();

  constructor(opts: PythAdapterOptions = {}) {
    this.fetchImpl = opts.fetchImpl ?? fetch;
    this.requestTimeoutMs = opts.requestTimeoutMs ?? 3000;
  }

  async getSpotPrice(symbol: string): Promise<PythSpotResult | null> {
    const upper = symbol.toUpperCase();
    const feedId = PYTH_PRICE_IDS[upper];
    if (!feedId) return null;

    const cached = this.cache.get(upper);
    if (cached && Date.now() - cached.ts < 60_000) return cached.data;

    try {
      const url = `${PYTH_API}?ids[]=${feedId}`;
      const res = await this.fetchImpl(url, {
        signal: AbortSignal.timeout(this.requestTimeoutMs),
      });
      if (!res.ok) return null;
      const raw = (await res.json()) as any;
      const parsed = raw?.parsed?.[0]?.price;
      if (!parsed) return null;
      const price = parseFloat(parsed.price) * Math.pow(10, parsed.expo);

      const result: PythSpotResult = {
        symbol: upper,
        price,
        timestamp: new Date(parsed.publish_time * 1000).toISOString(),
        source: {
          provider: "pyth",
          feed_id: feedId,
          fetched_at: new Date().toISOString(),
          response_hash: hashInput(parsed),
        },
      };

      this.cache.set(upper, { data: result, ts: Date.now() });
      return result;
    } catch (err) {
      console.warn(`Pyth fetch failed for ${upper}:`, err);
      return null;
    }
  }
}
