// src/codes/detectors/index.ts
// Fully-implemented detectors covering all three pillars:
//  - X01 EXECUTION_UNBOUND (prediction markets + perps)
//  - U03 UNFALSIFIABLE (universal)
//  - R01 REFLEXIVITY_RISK (perps) — uses CoinGlass liquidation cluster data
//  - R02 FUNDING_DECAY (perps)
//
// These are the shipping-ready reference implementations. Other codes follow
// the same pattern.

import type { Detector, EngineInput, LFTrigger } from "../../engine/core.js";
import { hashInput } from "../../engine/core.js";
import { getWeight } from "../registry.js";

// ============================================================================
// X01 — EXECUTION_UNBOUND
// ============================================================================

export class X01_Detector implements Detector {
  readonly code = "X01";

  detect(input: EngineInput): LFTrigger | null {
    const { thesis, marketState } = input;
    const trade = thesis.proposed_trade;

    const reasons: string[] = [];
    let severity: "high" | "critical" = "high";

    // Check 1: size vs liquidity
    if (
      marketState?.liquidity_depth_usdc !== undefined &&
      trade.size_usdc > marketState.liquidity_depth_usdc * 0.1
    ) {
      reasons.push(
        `Size ${trade.size_usdc} USDC exceeds 10% of liquidity depth (${marketState.liquidity_depth_usdc} USDC)`
      );
      severity = "critical";
    }

    // Check 2: spread eats edge
    if (
      marketState?.spread_bps !== undefined &&
      marketState.spread_bps > 200
    ) {
      reasons.push(
        `Spread ${marketState.spread_bps}bps is wide; edge may not survive execution`
      );
    }

    // Check 3: perp — leverage inconsistent with confidence
    if (trade.leverage !== undefined && trade.leverage > 1) {
      const maxSafeLeverage = trade.confidence * 10; // heuristic: 10x max at full confidence
      if (trade.leverage > maxSafeLeverage) {
        reasons.push(
          `Leverage ${trade.leverage}x exceeds confidence-appropriate max (${maxSafeLeverage.toFixed(1)}x)`
        );
        severity = "critical";
      }
    }

    if (reasons.length === 0) return null;

    return {
      code: "X01",
      name: "EXECUTION_UNBOUND",
      severity,
      weight: getWeight("X01", severity),
      reason: reasons.join("; "),
      input_hash: hashInput({
        size: trade.size_usdc,
        leverage: trade.leverage ?? null,
        confidence: trade.confidence,
        liquidity: marketState?.liquidity_depth_usdc ?? null,
        spread: marketState?.spread_bps ?? null,
      }),
    };
  }
}

// ============================================================================
// U03 — UNFALSIFIABLE
// ============================================================================

const VACUOUS_PATTERNS = [
  /things don'?t happen/i,
  /market resolves differently/i,
  /market resolves (yes|no)/i,
  /doesn'?t (work|pan out)/i,
  /i'?m wrong/i,
  /^\s*if wrong\s*$/i,
  /^\s*n\/?a\s*$/i,
  /^\s*none\s*$/i,
  /^\s*idk\s*$/i,
];

export class U03_Detector implements Detector {
  readonly code = "U03";

  detect(input: EngineInput): LFTrigger | null {
    const { thesis } = input;
    const condition = thesis.falsification_condition?.trim();

    // Missing entirely
    if (!condition || condition.length < 5) {
      return {
        code: "U03",
        name: "UNFALSIFIABLE",
        severity: "medium",
        weight: getWeight("U03", "medium"),
        reason:
          "No falsification condition provided. State what would prove the thesis wrong.",
        input_hash: hashInput({ condition: null }),
      };
    }

    // Vacuous — matches known empty patterns
    const isVacuous = VACUOUS_PATTERNS.some((p) => p.test(condition));
    if (isVacuous) {
      return {
        code: "U03",
        name: "UNFALSIFIABLE",
        severity: "medium",
        weight: getWeight("U03", "medium"),
        reason: `Falsification condition is vacuous: "${condition}". Provide a specific observable condition.`,
        input_hash: hashInput({ condition }),
      };
    }

    // Tautological — condition just restates market resolution
    const restatesResolution =
      condition.toLowerCase().includes("resolves no") ||
      condition.toLowerCase().includes("resolves yes") ||
      condition.toLowerCase() === thesis.target_outcome.toLowerCase();
    if (restatesResolution) {
      return {
        code: "U03",
        name: "UNFALSIFIABLE",
        severity: "medium",
        weight: getWeight("U03", "medium"),
        reason:
          "Falsification condition is tautological (just restates market resolution). Provide an independent observable.",
        input_hash: hashInput({ condition }),
      };
    }

    return null;
  }
}

// ============================================================================
// R02 — FUNDING_DECAY
// ============================================================================

export class R02_Detector implements Detector {
  readonly code = "R02";

  detect(input: EngineInput): LFTrigger | null {
    const { thesis, perpState } = input;

    // Only applies to perps
    if (thesis.market.venue !== "hyperliquid") return null;
    if (!perpState) return null;
    if (!thesis.perp_context) return null;

    const trade = thesis.proposed_trade;
    if (trade.direction !== "long" && trade.direction !== "short") return null;
    if (!trade.entry_price || !trade.target_price) return null;

    // Compute hold duration in 8h intervals
    const submittedAt = new Date(thesis.submitted_at).getTime();
    const deadlineAt = new Date(thesis.deadline).getTime();
    const holdMs = deadlineAt - submittedAt;
    const holdIntervals = Math.max(1, holdMs / (8 * 60 * 60 * 1000));

    // Longs pay positive funding; shorts receive it
    const direction = trade.direction === "long" ? 1 : -1;
    const fundingCostPerInterval = perpState.current_funding_rate_8h * direction;
    const totalFundingCost = fundingCostPerInterval * holdIntervals;

    // If trader receives funding, no flag
    if (totalFundingCost <= 0) return null;

    // Deterministic implied edge: abs move pct * confidence
    const movePct = Math.abs(trade.target_price - trade.entry_price) / trade.entry_price;
    const impliedEdge = movePct * trade.confidence;

    if (impliedEdge <= 0) return null;

    const consumptionRatio = totalFundingCost / impliedEdge;

    let severity: "medium" | "high" | "critical" | null = null;
    if (consumptionRatio >= 1.0) severity = "critical";
    else if (consumptionRatio >= 0.5) severity = "high";
    else if (consumptionRatio >= 0.25) severity = "medium";

    if (!severity) return null;

    return {
      code: "R02",
      name: "FUNDING_DECAY",
      severity,
      weight: getWeight("R02", severity),
      reason:
        `Expected funding cost ${(totalFundingCost * 100).toFixed(2)}% ` +
        `consumes ${(consumptionRatio * 100).toFixed(0)}% of implied edge ` +
        `(${(impliedEdge * 100).toFixed(2)}%) over ${holdIntervals.toFixed(1)} 8h intervals.`,
      input_hash: hashInput({
        direction: trade.direction,
        funding_rate_8h: perpState.current_funding_rate_8h,
        hold_intervals: holdIntervals,
        move_pct: movePct,
        confidence: trade.confidence,
      }),
    };
  }
}

// ============================================================================
// R01 — REFLEXIVITY_RISK
// ============================================================================

/**
 * Detects when a trader's stop-loss is near a liquidation cluster such that
 * triggering would cascade liquidations and move the market against them.
 *
 * With CoinGlass liquidation map data, this is no longer heuristic — it uses
 * actual historical liquidation density.
 */
export class R01_Detector implements Detector {
  readonly code = "R01";

  detect(input: EngineInput): LFTrigger | null {
    const { thesis, perpState } = input;

    if (thesis.market.venue !== "hyperliquid") return null;
    if (!perpState?.nearest_liquidation_cluster) return null;

    const trade = thesis.proposed_trade;
    const stop = trade.stop_price;
    if (!stop) return null;

    const cluster = perpState.nearest_liquidation_cluster;
    const clusterPrice = cluster.price;
    if (!(clusterPrice > 0)) return null;

    const proximityPct = Math.abs(stop - clusterPrice) / clusterPrice;

    // If stop is more than 2% from cluster, no flag
    if (proximityPct > 0.02) return null;

    // Severity scaling:
    //  - Within 0.5% of cluster with large at-cluster depth → CRITICAL
    //  - Within 1% → HIGH
    //  - Within 2% → MEDIUM
    let severity: "medium" | "high" | "critical";
    if (proximityPct <= 0.005 && cluster.at_cluster_depth_usd > 1_000_000) {
      severity = "critical";
    } else if (proximityPct <= 0.01) {
      severity = "high";
    } else {
      severity = "medium";
    }

    return {
      code: "R01",
      name: "REFLEXIVITY_RISK",
      severity,
      weight: getWeight("R01", severity),
      reason:
        `Stop ${stop} is within ${(proximityPct * 100).toFixed(2)}% of liquidation ` +
        `cluster at ${clusterPrice} (${formatUsd(cluster.at_cluster_depth_usd)} ` +
        `accumulated). Triggering may cascade liquidations against position.`,
      input_hash: hashInput({
        stop,
        cluster_price: clusterPrice,
        cluster_depth: cluster.at_cluster_depth_usd,
        proximity: proximityPct,
      }),
    };
  }
}

function formatUsd(n: number): string {
  if (n >= 1e9) return `$${(n / 1e9).toFixed(1)}B`;
  if (n >= 1e6) return `$${(n / 1e6).toFixed(1)}M`;
  if (n >= 1e3) return `$${(n / 1e3).toFixed(0)}K`;
  return `$${n.toFixed(0)}`;
}

// ============================================================================
// Registry of all shipping detectors
// ============================================================================

/**
 * The canonical ordered list of detectors the engine runs.
 * Order does not affect verdict correctness (detectors are independent),
 * but does affect the order codes appear in receipts.
 */
export function defaultDetectors(): Detector[] {
  return [
    new X01_Detector(),
    new U03_Detector(),
    new R01_Detector(),
    new R02_Detector(),
    // TODO: Add remaining 20 codes in subsequent sessions:
    // S01, S02, E01, E02, E03, I01, I02, T01, T02, X02,
    // A01, O01, U01, U02, U04, U05
  ];
}
