// src/codes/registry.ts
// Canonical LF code registry.
// Every finding in the DJZS taxonomy is defined here. Weights, categories,
// and plain-English labels are single-sourced.

export type Category =
  | "structural"
  | "evidence"
  | "incentive"
  | "temporal"
  | "execution"
  | "assumptions"
  | "reflexivity"
  | "oracle"
  | "universal";

export type Severity = "low" | "medium" | "high" | "critical";

export interface LFCodeDef {
  code: string;
  name: string;
  category: Category;
  label: string; // Plain English
  description: string; // What the trader should understand
  // Weights per severity. Not all codes use all severities.
  weights: Partial<Record<Severity, number>>;
  // If true, any trigger of this code forces ABORT regardless of total score.
  criticalForcesAbort: boolean;
  // Does this code require a specific venue type?
  venueRestriction?: "prediction_market" | "perp" | "any";
}

export const LF_CODES: Record<string, LFCodeDef> = {
  // ========== Structural ==========
  S01: {
    code: "S01",
    name: "STRUCTURAL_COPY",
    category: "structural",
    label: "Copy-trade structure detected",
    description:
      "Thesis appears to mirror another trader's position without independent rationale.",
    weights: { medium: 12, high: 18, critical: 25 },
    criticalForcesAbort: false,
    venueRestriction: "any",
  },
  S02: {
    code: "S02",
    name: "PROPOSITION_OUTCOME_MISMATCH",
    category: "structural",
    label: "Proposition and market resolution diverge",
    description:
      "The world-event your thesis describes does not match what the market actually resolves on.",
    weights: { medium: 14, high: 20 },
    criticalForcesAbort: false,
    venueRestriction: "any",
  },

  // ========== Evidence ==========
  E01: {
    code: "E01",
    name: "EVIDENCE_ABSENT",
    category: "evidence",
    label: "No supporting evidence found",
    description:
      "No verifiable public evidence was found supporting the load-bearing claims of the thesis.",
    weights: { medium: 12, high: 20 },
    criticalForcesAbort: false,
    venueRestriction: "any",
  },
  E02: {
    code: "E02",
    name: "EVIDENCE_STALE",
    category: "evidence",
    label: "Evidence is outdated",
    description:
      "Supporting evidence exists but is older than the thesis's relevance window.",
    weights: { low: 6, medium: 10, high: 14 },
    criticalForcesAbort: false,
    venueRestriction: "any",
  },
  E03: {
    code: "E03",
    name: "EVIDENCE_CONFLICTED",
    category: "evidence",
    label: "Sources disagree",
    description:
      "Multiple sources report materially contradictory information about the load-bearing claim.",
    weights: { medium: 12, high: 18 },
    criticalForcesAbort: false,
    venueRestriction: "any",
  },

  // ========== Incentive ==========
  I01: {
    code: "I01",
    name: "FOMO_LOOP",
    category: "incentive",
    label: "FOMO-driven sizing",
    description:
      "Thesis or sizing patterns indicate FOMO-driven decision-making rather than evidence-based sizing.",
    weights: { medium: 10, high: 15 },
    criticalForcesAbort: false,
    venueRestriction: "any",
  },
  I02: {
    code: "I02",
    name: "INCENTIVE_MISALIGN",
    category: "incentive",
    label: "Incentive misalignment",
    description:
      "The trader's incentives (leverage, position sizing) are misaligned with the stated confidence level.",
    weights: { medium: 10, high: 15 },
    criticalForcesAbort: false,
    venueRestriction: "any",
  },

  // ========== Temporal ==========
  T01: {
    code: "T01",
    name: "TEMPORAL_DRIFT",
    category: "temporal",
    label: "Timing window mismatch",
    description:
      "Trader's internal deadline is inconsistent with market resolution deadline.",
    weights: { low: 6, medium: 12 },
    criticalForcesAbort: false,
    venueRestriction: "any",
  },
  T02: {
    code: "T02",
    name: "MARKET_MOVED_PRE_CONFIRMATION",
    category: "temporal",
    label: "Market moved before public confirmation",
    description:
      "Price moved significantly before any public information event. Pattern consistent with MNPI — not a determination of wrongdoing.",
    weights: { high: 18, critical: 25 },
    criticalForcesAbort: false,
    venueRestriction: "any",
  },

  // ========== Execution ==========
  X01: {
    code: "X01",
    name: "EXECUTION_UNBOUND",
    category: "execution",
    label: "Execution unbound by constraints",
    description:
      "Trade lacks execution constraints (size/slippage/fees accounting). Edge may not survive execution costs.",
    weights: { high: 20, critical: 30 },
    criticalForcesAbort: false,
    venueRestriction: "any",
  },
  X02: {
    code: "X02",
    name: "RESOLUTION_SOURCE_UNREACHABLE",
    category: "execution",
    label: "Resolution source unreachable",
    description:
      "The market's declared resolution source could not be reached at audit time.",
    weights: { medium: 10, high: 15, critical: 20 },
    criticalForcesAbort: false,
    venueRestriction: "prediction_market",
  },

  // ========== Assumptions ==========
  A01: {
    code: "A01",
    name: "ASSUMPTIONS_IMPLICIT",
    category: "assumptions",
    label: "Implicit assumptions",
    description:
      "Non-trivial thesis with no stated key assumptions. The thesis depends on things you haven't named.",
    weights: { low: 4, medium: 8 },
    criticalForcesAbort: false,
    venueRestriction: "any",
  },

  // ========== Reflexivity (perps) ==========
  R01: {
    code: "R01",
    name: "REFLEXIVITY_RISK",
    category: "reflexivity",
    label: "Stop near liquidation cluster",
    description:
      "Thesis stop-loss is near a liquidation cluster. Triggering may cascade liquidations and reverse against you.",
    weights: { medium: 12, high: 20, critical: 28 },
    criticalForcesAbort: false,
    venueRestriction: "perp",
  },
  R02: {
    code: "R02",
    name: "FUNDING_DECAY",
    category: "reflexivity",
    label: "Funding cost erodes edge",
    description:
      "Expected funding cost over hold duration consumes a material portion of implied edge.",
    weights: { medium: 10, high: 16, critical: 25 },
    criticalForcesAbort: false,
    venueRestriction: "perp",
  },

  // ========== Oracle (perps) ==========
  O01: {
    code: "O01",
    name: "ORACLE_DIVERGENCE",
    category: "oracle",
    label: "Oracle vs spot divergence",
    description:
      "Perp's oracle price diverges from spot reference. Settlement may differ from displayed price.",
    weights: { medium: 8, high: 14, critical: 22 },
    criticalForcesAbort: false,
    venueRestriction: "perp",
  },

  // ========== Universal ==========
  U01: {
    code: "U01",
    name: "NONSENSICAL_INPUT",
    category: "universal",
    label: "Input does not describe a tradable thesis",
    description: "The input does not constitute a coherent tradable thesis.",
    weights: { critical: 40 },
    criticalForcesAbort: true,
    venueRestriction: "any",
  },
  U02: {
    code: "U02",
    name: "CONFIDENCE_SIZE_MISMATCH",
    category: "universal",
    label: "Confidence-size mismatch",
    description:
      "Position size is inconsistent with stated confidence. Low confidence + large size is structurally wrong.",
    weights: { medium: 8, high: 14 },
    criticalForcesAbort: false,
    venueRestriction: "any",
  },
  U03: {
    code: "U03",
    name: "UNFALSIFIABLE",
    category: "universal",
    label: "Thesis is unfalsifiable",
    description:
      "No falsification condition was stated, or the stated condition is vacuous. If you can't say what would prove you wrong, you're not trading on edge.",
    weights: { medium: 12 },
    criticalForcesAbort: false,
    venueRestriction: "any",
  },
  U04: {
    code: "U04",
    name: "MNPI_DECLARED",
    category: "universal",
    label: "MNPI declared by trader",
    description:
      "Trader declared information source as private or mixed. DJZS records this declaration; it does not determine legality.",
    weights: { high: 18, critical: 30 },
    criticalForcesAbort: false,
    venueRestriction: "any",
  },
  U05: {
    code: "U05",
    name: "PROVENANCE_UNCLEAR",
    category: "universal",
    label: "Information source unspecified",
    description:
      "Trader did not specify information source type. Provenance matters for regulatory posture.",
    weights: { low: 5, medium: 10 },
    criticalForcesAbort: false,
    venueRestriction: "any",
  },
} as const;

// ============================================================================
// Derived constants
// ============================================================================

/** Maximum possible risk score (all codes at maximum severity). */
export const RISK_CEILING = Object.values(LF_CODES).reduce((sum, def) => {
  const maxWeight = Math.max(...Object.values(def.weights));
  return sum + maxWeight;
}, 0);

/** Score bands for public interpretation. */
export const SCORE_BANDS = {
  pass: { min: 0, max: 19, label: "OPERATIONALLY_ACCEPTABLE" },
  pass_with_notes: { min: 20, max: 49, label: "CAUTION" },
  abort: { min: 50, max: 89, label: "HIGH_RISK" },
  hard_abort: { min: 90, max: Infinity, label: "REJECT" },
} as const;

export function getCodeDef(code: string): LFCodeDef {
  const def = LF_CODES[code];
  if (!def) {
    throw new Error(`Unknown LF code: ${code}`);
  }
  return def;
}

export function getWeight(code: string, severity: Severity): number {
  const def = getCodeDef(code);
  const weight = def.weights[severity];
  if (weight === undefined) {
    throw new Error(`Code ${code} does not support severity ${severity}`);
  }
  return weight;
}
