// src/engine/audit.ts
// High-level audit orchestration. Wires adapters → engine → receipt.
//
// Perp market data comes from CoinGlass (multi-venue aggregation), not from
// any single exchange. Spot reference comes from Pyth when available.

import { parseThesis, type ParseResult } from "../schema/thesis.js";
import { computeVerdict, type EngineInput } from "./core.js";
import { defaultDetectors } from "../codes/detectors/index.js";
import { generateReceipt, type DJZSReceipt } from "../receipts/schema.js";
import { PolymarketAdapter } from "../adapters/polymarket.js";
import {
  CoinGlassAdapter,
  type SourceMetadata,
} from "../adapters/coinglass.js";
import { PythSpotAdapter } from "../adapters/pyth.js";

export interface AuditResult {
  success: boolean;
  receipt?: DJZSReceipt;
  parse_errors?: ParseResult["errors"];
  message: string;
  /** Source metadata for all external data used in the audit. */
  data_sources?: SourceMetadata[];
}

export interface AuditContext {
  polymarket?: PolymarketAdapter;
  coinglass?: CoinGlassAdapter;
  pyth?: PythSpotAdapter;
  /**
   * Whether to proceed without a CoinGlass API key. Perp audits without
   * CoinGlass run with degraded confidence (no OI, funding, or liquidation
   * cluster data). Set true only for test/dev.
   */
  allowDegradedPerpMode?: boolean;
}

export async function runAudit(
  rawInput: unknown,
  context: AuditContext = {}
): Promise<AuditResult> {
  const audit_requested_at = new Date().toISOString();

  // ---- Step 1: parse and validate input ----
  const parsed = parseThesis(rawInput);
  if (!parsed.success || !parsed.thesis) {
    return {
      success: false,
      parse_errors: parsed.errors,
      message:
        "Thesis did not parse. Fix the errors in parse_errors and resubmit. Parse failures are not charged.",
    };
  }

  const thesis = parsed.thesis;
  const data_sources: SourceMetadata[] = [];

  // ---- Step 2: pull external state via adapters ----
  const engineInput: EngineInput = { thesis };

  if (thesis.market.venue === "polymarket") {
    const adapter = context.polymarket ?? new PolymarketAdapter();
    const parsedUrl = PolymarketAdapter.parseMarketUrl(thesis.market.market_url);
    if (parsedUrl) {
      engineInput.marketState =
        (await adapter.getMarketState(parsedUrl.slug)) ?? undefined;
    }
    if (thesis.market.resolution_source_url) {
      const check = await adapter.checkResolutionSource(
        thesis.market.resolution_source_url
      );
      engineInput.evidenceSnapshot = {
        sources_queried: [],
        events_collected: [],
        contradictions: [],
        resolution_source_check: check,
      };
    }
  } else if (thesis.market.venue === "hyperliquid") {
    // Perp audit: CoinGlass for derivatives state, Pyth for spot reference
    if (!context.coinglass && !context.allowDegradedPerpMode) {
      return {
        success: false,
        message:
          "Perp audit requires CoinGlassAdapter in audit context. " +
          "Set CG_API_KEY env var and pass CoinGlassAdapter. " +
          "Pass allowDegradedPerpMode:true only for test/dev.",
      };
    }

    const pyth = context.pyth ?? new PythSpotAdapter();

    if (context.coinglass && thesis.perp_context) {
      const symbol = thesis.perp_context.pair.replace(/-PERP$/i, "");
      const perpResult = await context.coinglass.getPerpState(symbol);
      if (perpResult) {
        engineInput.perpState = perpResult.state;
        data_sources.push(...perpResult.sources);

        // Fill oracle_price from Pyth spot (best available reference)
        const spot = await pyth.getSpotPrice(symbol);
        if (spot) {
          engineInput.perpState.oracle_price = spot.price;
          engineInput.perpState.spot_reference_price = spot.price;
        } else if (thesis.perp_context.oracle_price) {
          engineInput.perpState.oracle_price = thesis.perp_context.oracle_price;
        }

        // Compute cluster distance now that we have a reference price
        const cluster = engineInput.perpState.nearest_liquidation_cluster;
        if (cluster && engineInput.perpState.oracle_price > 0) {
          cluster.distance_pct =
            Math.abs(cluster.price - engineInput.perpState.oracle_price) /
            engineInput.perpState.oracle_price;
        }

        // Basic market state for X01 checks (liquidity proxy via OI)
        engineInput.marketState = {
          current_price: engineInput.perpState.oracle_price,
          liquidity_depth_usdc:
            (engineInput.perpState.open_interest_usd ?? 0) * 0.01,
          volume_24h_usdc: undefined,
          spread_bps: undefined,
          fetched_at: new Date().toISOString(),
          source_response_hash: perpResult.sources
            .map((s) => s.response_hash)
            .join(":"),
        };
      }
    }
  }

  // ---- Step 3: compute verdict ----
  const verdict = computeVerdict(engineInput, defaultDetectors());

  // ---- Step 4: generate receipt ----
  const receipt = generateReceipt({
    thesis,
    verdict,
    market_state: engineInput.marketState,
    perp_state: engineInput.perpState,
    evidence_snapshot: engineInput.evidenceSnapshot,
    audit_requested_at,
  });

  return {
    success: true,
    receipt,
    data_sources,
    message: `Audit complete: ${verdict.verdict} (score ${verdict.risk_score}/${verdict.risk_ceiling})`,
  };
}
