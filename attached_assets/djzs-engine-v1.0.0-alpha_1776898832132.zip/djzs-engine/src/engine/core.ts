// src/engine/core.ts
// DJZSEngine — deterministic verdict computation.
// No LLM calls live here. No network calls live here. Pure TypeScript.
// Every computation is reproducible from the same inputs.

import pkg from "js-sha3";
const { sha3_256 } = pkg;
import type { StructuredThesis } from "../schema/thesis.js";
import { LF_CODES, SCORE_BANDS, getCodeDef, type Severity } from "../codes/registry.js";

export const ENGINE_VERSION = "djzs-engine-v1.0.0-alpha";
export const TAXONOMY_VERSION = "djzs-lf-v1.2";
export const POLICY_VERSION = "djzs-policy-v1";

// ============================================================================
// Types
// ============================================================================

export type Verdict = "PASS" | "PASS_WITH_NOTES" | "ABORT" | "REVIEW";

export interface LFTrigger {
  code: string;
  name: string;
  severity: Severity;
  weight: number;
  reason: string;
  evidence?: string[]; // Supporting data references
  input_hash: string; // Hash of inputs that triggered this
}

export interface Remediation {
  code: string;
  field: string;
  current_value: string | null;
  required_change: string;
  example?: string;
}

export interface EngineInput {
  thesis: StructuredThesis;
  // External data passed in by adapters — engine does NOT fetch these itself
  marketState?: MarketStateInput;
  evidenceSnapshot?: EvidenceSnapshotInput;
  perpState?: PerpStateInput;
}

export interface MarketStateInput {
  current_price: number;
  price_at_t_minus_1h?: number;
  price_at_t_minus_24h?: number;
  spread_bps?: number;
  liquidity_depth_usdc?: number;
  volume_24h_usdc?: number;
  fetched_at: string;
  source_response_hash: string;
}

export interface EvidenceSnapshotInput {
  sources_queried: Array<{
    source_name: string;
    source_tier: "official" | "wire" | "news" | "social";
    reachable: boolean;
    returned_data: boolean;
    n_results: number;
  }>;
  events_collected: Array<{
    event_id: string;
    source_name: string;
    event_timestamp: string;
    summary: string;
    relates_to_claim_hash?: string;
  }>;
  contradictions: Array<{
    claim_hash: string;
    supporting_event_ids: string[];
    contradicting_event_ids: string[];
    severity: "minor" | "material" | "fundamental";
  }>;
  resolution_source_check?: {
    url: string | null;
    reachable: boolean;
    returned_data: boolean;
  };
}

export interface PerpStateInput {
  oracle_price: number;
  spot_reference_price?: number;
  current_funding_rate_8h: number;
  open_interest_usd?: number;
  // Liquidation cluster proximity (v1 coarse heuristic)
  nearest_liquidation_cluster?: {
    price: number;
    distance_pct: number;
    upstream_depth_usd: number;
    at_cluster_depth_usd: number;
  };
}

export interface EngineVerdict {
  verdict: Verdict;
  risk_score: number;
  risk_ceiling: number;
  triggered_codes: LFTrigger[];
  remediation: Remediation[];
  computed_by: string;
  taxonomy_version: string;
  policy_version: string;
  compute_hash: string;
  computed_at: string;
}

// ============================================================================
// Hashing
// ============================================================================

export function keccak256(input: string): string {
  return sha3_256(input);
}

/**
 * Canonical JSON serialization for deterministic hashing.
 * Objects have their keys sorted alphabetically before stringification.
 *
 * Undefined values in objects are OMITTED (not serialized as null), matching
 * JSON.stringify's behavior. This preserves the round-trip invariant:
 *   canonicalJSON(x) === canonicalJSON(JSON.parse(JSON.stringify(x)))
 */
export function canonicalJSON(value: unknown): string {
  if (value === undefined) return "null"; // top-level only
  if (value === null) return "null";
  if (typeof value === "number") return JSON.stringify(value);
  if (typeof value === "string") return JSON.stringify(value);
  if (typeof value === "boolean") return JSON.stringify(value);
  if (Array.isArray(value)) {
    return "[" + value.map((v) => canonicalJSON(v === undefined ? null : v)).join(",") + "]";
  }
  if (typeof value === "object") {
    const src = value as Record<string, unknown>;
    const keys = Object.keys(src)
      .filter((k) => src[k] !== undefined)
      .sort();
    const entries = keys.map(
      (k) => JSON.stringify(k) + ":" + canonicalJSON(src[k])
    );
    return "{" + entries.join(",") + "}";
  }
  return "null";
}

export function hashInput(input: unknown): string {
  return keccak256(canonicalJSON(input));
}

// ============================================================================
// Detector interface
// ============================================================================

export interface Detector {
  readonly code: string;
  /** Returns a trigger if the code fires, null otherwise. */
  detect(input: EngineInput): LFTrigger | null;
}

// ============================================================================
// Main entry point
// ============================================================================

export function computeVerdict(
  input: EngineInput,
  detectors: Detector[]
): EngineVerdict {
  const triggered: LFTrigger[] = [];

  for (const detector of detectors) {
    try {
      const trigger = detector.detect(input);
      if (trigger !== null) {
        triggered.push(trigger);
      }
    } catch (err) {
      // A detector crash is a bug; do not silently swallow it.
      // Log and continue so one broken code doesn't kill the whole audit.
      console.error(`Detector ${detector.code} crashed:`, err);
    }
  }

  const risk_score = triggered.reduce((sum, t) => sum + t.weight, 0);
  const risk_ceiling = computeRiskCeiling();

  const verdict = decideVerdict(risk_score, triggered);
  const remediation = generateRemediation(triggered, input.thesis);

  const partial = {
    verdict,
    risk_score,
    risk_ceiling,
    triggered_codes: triggered,
    remediation,
    computed_by: ENGINE_VERSION,
    taxonomy_version: TAXONOMY_VERSION,
    policy_version: POLICY_VERSION,
    computed_at: new Date().toISOString(),
  };

  const compute_hash = hashInput({
    thesis_hash: hashInput(input.thesis),
    triggered_codes: triggered.map((t) => ({
      code: t.code,
      severity: t.severity,
      weight: t.weight,
    })),
    risk_score,
    verdict,
    engine: ENGINE_VERSION,
    taxonomy: TAXONOMY_VERSION,
    policy: POLICY_VERSION,
  });

  return { ...partial, compute_hash };
}

// ============================================================================
// Verdict decision
// ============================================================================

function decideVerdict(
  score: number,
  triggered: LFTrigger[]
): Verdict {
  // Any code that forces ABORT by definition
  const forcesAbort = triggered.some((t) => {
    const def = getCodeDef(t.code);
    return def.criticalForcesAbort && t.severity === "critical";
  });
  if (forcesAbort) return "ABORT";

  // Any critical-severity trigger (even if the code itself doesn't force abort)
  // means HARD_ABORT territory
  const hasCritical = triggered.some((t) => t.severity === "critical");
  if (hasCritical && score >= SCORE_BANDS.abort.min) return "ABORT";

  if (score >= SCORE_BANDS.hard_abort.min) return "ABORT";
  if (score >= SCORE_BANDS.abort.min) return "ABORT";
  if (score >= SCORE_BANDS.pass_with_notes.min) return "PASS_WITH_NOTES";
  return "PASS";
}

function computeRiskCeiling(): number {
  return Object.values(LF_CODES).reduce((sum, def) => {
    const maxWeight = Math.max(...Object.values(def.weights));
    return sum + maxWeight;
  }, 0);
}

// ============================================================================
// Remediation generator
// ============================================================================

function generateRemediation(
  triggered: LFTrigger[],
  thesis: StructuredThesis
): Remediation[] {
  return triggered.map((t) => remediationFor(t, thesis));
}

function remediationFor(
  trigger: LFTrigger,
  thesis: StructuredThesis
): Remediation {
  const defaults: Remediation = {
    code: trigger.code,
    field: "thesis",
    current_value: null,
    required_change: "See code documentation for resolution guidance.",
  };

  switch (trigger.code) {
    case "A01":
      return {
        code: trigger.code,
        field: "key_assumptions",
        current_value:
          thesis.key_assumptions.length === 0 ? "empty" : "insufficient",
        required_change:
          "State the key assumptions your thesis depends on. What must be true for this to work?",
        example:
          "['Fed follows previous dovish guidance', 'CPI print lands under 3.0%', 'No intermeeting surprises']",
      };
    case "U03":
      return {
        code: trigger.code,
        field: "falsification_condition",
        current_value: thesis.falsification_condition || null,
        required_change:
          "State the specific observable condition that would prove this thesis wrong.",
        example:
          "'If BTC closes below $95,000 for two consecutive daily candles, the thesis is invalidated.'",
      };
    case "U04":
      return {
        code: trigger.code,
        field: "information_source_type",
        current_value: thesis.information_source_type,
        required_change:
          "Review whether this trade is based on non-public information. DJZS records your declaration; you are responsible for legal compliance.",
      };
    case "U05":
      return {
        code: trigger.code,
        field: "information_source_type",
        current_value: "unspecified",
        required_change:
          "Declare whether your information source is public, private, or mixed.",
      };
    case "S02":
      return {
        code: trigger.code,
        field: "target_outcome",
        current_value: thesis.target_outcome,
        required_change:
          "Align target_outcome with the market's actual resolution criteria. Verify what YES and NO specifically resolve on.",
      };
    case "E01":
      return {
        code: trigger.code,
        field: "evidence_claims",
        current_value:
          thesis.evidence_claims.length === 0
            ? "empty"
            : `${thesis.evidence_claims.length} claims, no evidence found`,
        required_change:
          "Add evidence claims with verifiable source URLs for load-bearing claims.",
      };
    case "E02":
      return {
        code: trigger.code,
        field: "evidence_claims",
        current_value: "stale sources",
        required_change:
          "Replace outdated sources with current reporting (within 7 days for fast-moving markets).",
      };
    case "E03":
      return {
        code: trigger.code,
        field: "evidence_claims",
        current_value: "sources conflict",
        required_change:
          "Reconcile contradictory sources or identify which you trust more and why.",
      };
    case "T01":
      return {
        code: trigger.code,
        field: "deadline",
        current_value: thesis.deadline,
        required_change:
          "Align your internal deadline with market resolution deadline.",
      };
    case "T02":
      return {
        code: trigger.code,
        field: "information_source_type",
        current_value: thesis.information_source_type,
        required_change:
          "Market moved before public confirmation. If you have non-public information, declare it in information_source_type.",
      };
    case "X01":
      return {
        code: trigger.code,
        field: "proposed_trade",
        current_value: `size ${thesis.proposed_trade.size_usdc} USDC`,
        required_change:
          "Verify size against liquidity, spread, and fees. Edge must survive execution costs.",
      };
    case "X02":
      return {
        code: trigger.code,
        field: "market.resolution_source_url",
        current_value: thesis.market.resolution_source_url || null,
        required_change:
          "Resolution source is unreachable. Verify the market's resolution mechanism before trading.",
      };
    case "R01":
      return {
        code: trigger.code,
        field: "proposed_trade.stop_price",
        current_value: thesis.proposed_trade.stop_price?.toString() || null,
        required_change:
          "Stop is near a liquidation cluster. Move stop beyond the cluster or size down.",
      };
    case "R02":
      return {
        code: trigger.code,
        field: "deadline",
        current_value: thesis.deadline,
        required_change:
          "Funding cost consumes material edge. Shorten deadline or increase target to restore edge.",
      };
    case "O01":
      return {
        code: trigger.code,
        field: "perp_context",
        current_value: "oracle diverges from spot",
        required_change:
          "Wait for oracle-spot convergence or account for settlement risk in sizing.",
      };
    case "U02":
      return {
        code: trigger.code,
        field: "proposed_trade",
        current_value: `confidence ${thesis.proposed_trade.confidence}, size ${thesis.proposed_trade.size_usdc}`,
        required_change:
          "Align position size with confidence. Low confidence + large size is structurally inconsistent.",
      };
    case "I01":
      return {
        code: trigger.code,
        field: "proposed_trade",
        current_value: null,
        required_change:
          "Re-examine whether sizing reflects evidence or FOMO. Reduce size or add evidence.",
      };
    case "I02":
      return {
        code: trigger.code,
        field: "proposed_trade",
        current_value: null,
        required_change:
          "Leverage and sizing are inconsistent with confidence. Reduce leverage or reduce size.",
      };
    case "S01":
      return {
        code: trigger.code,
        field: "key_assumptions",
        current_value: null,
        required_change:
          "Provide independent rationale for this position. Copy-trade structure requires explicit justification.",
      };
    default:
      return defaults;
  }
}
