// src/index.ts
// Public API surface of the @djzs/engine package.

export * from "./schema/thesis.js";
export * from "./codes/registry.js";
export * from "./engine/core.js";
export * from "./engine/audit.js";
export * from "./receipts/schema.js";
export * from "./codes/detectors/index.js";
export { PolymarketAdapter } from "./adapters/polymarket.js";
export { CoinGlassAdapter } from "./adapters/coinglass.js";
export type { SourceMetadata, CoinGlassResponse, FundingRateByExchange, OpenInterestByExchange, LiquidationSummary, LongShortRatio } from "./adapters/coinglass.js";
export { PythSpotAdapter, PYTH_PRICE_IDS } from "./adapters/pyth.js";
