// src/receipts/schema.ts
// Receipt schema v2 — evidence snapshots + deterministic hashing.

import type {
  EngineVerdict,
  LFTrigger,
  Remediation,
  MarketStateInput,
  EvidenceSnapshotInput,
  PerpStateInput,
} from "../engine/core.js";
import type { StructuredThesis } from "../schema/thesis.js";
import { canonicalJSON, hashInput, keccak256 } from "../engine/core.js";

export const RECEIPT_SCHEMA_VERSION = "receipt-v2";

export interface DJZSReceipt {
  // --- Identity ---
  receipt_id: string;
  schema_version: typeof RECEIPT_SCHEMA_VERSION;
  taxonomy_version: string;
  policy_version: string;
  sys_id: "djzs-mainnet-01";

  // --- Temporal ---
  audit_requested_at: string;
  audit_completed_at: string;
  anchored_at?: string; // Set when Irys confirms; absent until then

  // --- Inputs ---
  thesis: StructuredThesis;
  thesis_hash: string;

  // --- State at audit time ---
  market_state?: MarketStateInput;
  perp_state?: PerpStateInput;
  evidence_snapshot?: EvidenceSnapshotInput;

  // --- Engine output ---
  verdict: EngineVerdict["verdict"];
  risk_score: number;
  risk_ceiling: number;
  triggered_codes: LFTrigger[];
  remediation: Remediation[];
  computed_by: string;
  compute_hash: string;

  // --- Proof ---
  keccak_proof: string;

  // --- Disclaimers ---
  disclaimers: Disclaimers;

  // --- Irys anchoring (populated post-anchor) ---
  irys_tx_id?: string;
}

export interface Disclaimers {
  pass_does_not_guarantee_resolution: string;
  t02_pattern_not_intent?: string;
  perp_pre_trade_only?: string;
  mnpi_recorded?: string;
}

export const STANDARD_DISCLAIMERS = {
  pass_does_not_guarantee_resolution:
    "A PASS verdict means the thesis survived DJZS audit. It does not predict the market's resolution. DJZS catches avoidable logic, evidence, and execution failures. It does not catch epistemic failures — situations where your model of the world is wrong. The evidence snapshot in this receipt records what was knowable to the engine at audit time. Information that became available after audit_completed_at is not reflected in this verdict.",

  t02_pattern_not_intent:
    "LF code T02 detects a temporal pattern: market price movement preceding public confirmation. It is not a determination of insider trading, does not allege wrongdoing, and does not substitute for regulatory investigation. It is a signal for the trader to ask whether a counterparty may hold non-public information.",

  perp_pre_trade_only:
    "This audit reflects market state at audit_completed_at. Perp positions are subject to ongoing reflexivity (R01), funding decay (R02), and oracle divergence (O01) that may invalidate the thesis after entry. DJZS pre-trade audit does not monitor the position after entry. Re-audit at intervals appropriate to position duration.",

  mnpi_recorded:
    "The trader declared a non-public information source. DJZS records this declaration as part of the audit trail. DJZS does not determine legality of trading on this basis; that responsibility is the trader's.",
} as const;

// ============================================================================
// Generation
// ============================================================================

export interface ReceiptGeneratorInput {
  thesis: StructuredThesis;
  verdict: EngineVerdict;
  market_state?: MarketStateInput;
  perp_state?: PerpStateInput;
  evidence_snapshot?: EvidenceSnapshotInput;
  audit_requested_at: string;
}

export function generateReceipt(
  input: ReceiptGeneratorInput
): DJZSReceipt {
  const audit_completed_at = new Date().toISOString();
  const thesis_hash = hashInput(input.thesis);
  const receipt_id = `rcp_${keccak256(
    canonicalJSON({
      thesis_hash,
      audit_completed_at,
      compute_hash: input.verdict.compute_hash,
    })
  ).slice(0, 24)}`;

  const disclaimers: Disclaimers = {
    pass_does_not_guarantee_resolution:
      STANDARD_DISCLAIMERS.pass_does_not_guarantee_resolution,
  };

  // Conditional disclaimers
  if (input.verdict.triggered_codes.some((t) => t.code === "T02")) {
    disclaimers.t02_pattern_not_intent =
      STANDARD_DISCLAIMERS.t02_pattern_not_intent;
  }
  if (input.thesis.market.venue === "hyperliquid") {
    disclaimers.perp_pre_trade_only = STANDARD_DISCLAIMERS.perp_pre_trade_only;
  }
  if (
    input.thesis.information_source_type === "private" ||
    input.thesis.information_source_type === "mixed"
  ) {
    disclaimers.mnpi_recorded = STANDARD_DISCLAIMERS.mnpi_recorded;
  }

  const partial: Omit<DJZSReceipt, "keccak_proof"> = {
    receipt_id,
    schema_version: RECEIPT_SCHEMA_VERSION,
    taxonomy_version: input.verdict.taxonomy_version,
    policy_version: input.verdict.policy_version,
    sys_id: "djzs-mainnet-01",
    audit_requested_at: input.audit_requested_at,
    audit_completed_at,
    thesis: input.thesis,
    thesis_hash,
    market_state: input.market_state,
    perp_state: input.perp_state,
    evidence_snapshot: input.evidence_snapshot,
    verdict: input.verdict.verdict,
    risk_score: input.verdict.risk_score,
    risk_ceiling: input.verdict.risk_ceiling,
    triggered_codes: input.verdict.triggered_codes,
    remediation: input.verdict.remediation,
    computed_by: input.verdict.computed_by,
    compute_hash: input.verdict.compute_hash,
    disclaimers,
  };

  const keccak_proof = keccak256(canonicalJSON(partial));

  return { ...partial, keccak_proof };
}

/**
 * Re-verification — given a receipt, recompute the expected keccak_proof.
 * If the recomputed hash matches the receipt's keccak_proof, the receipt
 * has not been tampered with.
 *
 * NOTE: This only verifies the hash. To verify the verdict itself, re-run
 * computeVerdict with the same inputs and detectors.
 */
export function verifyReceiptHash(receipt: DJZSReceipt): {
  valid: boolean;
  expected: string;
  actual: string;
} {
  const { keccak_proof, anchored_at, irys_tx_id, ...rest } = receipt;
  const expected = keccak256(canonicalJSON(rest));
  return {
    valid: expected === keccak_proof,
    expected,
    actual: keccak_proof,
  };
}
