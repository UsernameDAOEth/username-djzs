// src/schema/thesis.ts
// Structured thesis schema — v1
// The input contract for all DJZS audits. Prose input is not accepted.

import { z } from "zod";

// ============================================================================
// Enums
// ============================================================================

export const VenueSchema = z.enum([
  "polymarket",
  "kalshi",
  "limitless",
  "hyperliquid",
  "other",
]);
export type Venue = z.infer<typeof VenueSchema>;

export const DirectionSchema = z.enum(["yes", "no", "long", "short"]);
export type Direction = z.infer<typeof DirectionSchema>;

export const InfoSourceTypeSchema = z.enum([
  "public",
  "private",
  "mixed",
  "unspecified",
]);
export type InfoSourceType = z.infer<typeof InfoSourceTypeSchema>;

// ============================================================================
// Sub-schemas
// ============================================================================

export const MarketRefSchema = z.object({
  venue: VenueSchema,
  market_id: z.string().min(1),
  market_url: z.string().url(),
  resolution_source_url: z.string().url().nullable().optional(),
  resolution_deadline: z.string().datetime().nullable().optional(),
});
export type MarketRef = z.infer<typeof MarketRefSchema>;

export const ProposedTradeSchema = z.object({
  direction: DirectionSchema,
  size_usdc: z.number().positive(),
  confidence: z.number().min(0).max(1),
  // For perps only:
  entry_price: z.number().positive().optional(),
  target_price: z.number().positive().optional(),
  stop_price: z.number().positive().optional(),
  leverage: z.number().positive().max(100).optional(),
});
export type ProposedTrade = z.infer<typeof ProposedTradeSchema>;

export const EvidenceClaimSchema = z.object({
  claim_text: z.string().min(1).max(500),
  claim_hash: z.string().optional(), // Computed by engine if missing
  source_url: z.string().url().optional(),
  source_timestamp: z.string().datetime().optional(),
  is_load_bearing: z.boolean(),
});
export type EvidenceClaim = z.infer<typeof EvidenceClaimSchema>;

export const PerpContextSchema = z.object({
  pair: z.string().min(1), // e.g. "BTC-PERP"
  current_funding_rate_8h: z.number(), // Can be negative
  open_interest_usd: z.number().nonnegative().optional(),
  oracle_price: z.number().positive(),
  spot_reference_price: z.number().positive().optional(),
  liquidation_price_estimate: z.number().positive().optional(),
});
export type PerpContext = z.infer<typeof PerpContextSchema>;

// ============================================================================
// Main thesis schema
// ============================================================================

export const StructuredThesisSchema = z
  .object({
    schema_version: z.literal("thesis-v1"),
    submitted_at: z.string().datetime(),

    // --- Required ---
    proposition: z
      .string()
      .min(10, "Proposition must be at least 10 characters")
      .max(280, "Proposition must be under 280 characters")
      .refine(
        (s) => !s.trim().endsWith("?"),
        "Proposition cannot be a question"
      )
      .refine(
        (s) => hasVerb(s),
        "Proposition must contain an action verb"
      )
      .refine(
        (s) => !containsHedging(s),
        "Proposition contains hedging language that defeats measurability (probably, might, could, soon, etc.)"
      ),
    target_outcome: z.string().min(10).max(500),
    deadline: z.string().datetime(),
    market: MarketRefSchema,
    proposed_trade: ProposedTradeSchema,
    information_source_type: InfoSourceTypeSchema,

    // --- Optional but scored ---
    key_assumptions: z.array(z.string().min(1).max(300)).default([]),
    evidence_claims: z.array(EvidenceClaimSchema).default([]),
    falsification_condition: z.string().min(5).max(500).optional(),
    information_source_details: z.string().optional(),
    perp_context: PerpContextSchema.optional(),
  })
  .refine(
    (t) => new Date(t.deadline) > new Date(t.submitted_at),
    { message: "Deadline must be after submission time", path: ["deadline"] }
  )
  .refine(
    (t) => t.market.venue !== "hyperliquid" || t.perp_context !== undefined,
    { message: "perp_context is required when venue is hyperliquid", path: ["perp_context"] }
  )
  .refine(
    (t) => {
      if (t.market.venue === "hyperliquid") {
        return (
          t.proposed_trade.direction === "long" ||
          t.proposed_trade.direction === "short"
        );
      }
      return (
        t.proposed_trade.direction === "yes" ||
        t.proposed_trade.direction === "no"
      );
    },
    {
      message: "Direction must match venue: yes/no for prediction markets, long/short for perps",
      path: ["proposed_trade", "direction"],
    }
  );

export type StructuredThesis = z.infer<typeof StructuredThesisSchema>;

// ============================================================================
// Validation helpers
// ============================================================================

const HEDGING_WORDS = [
  "probably",
  "maybe",
  "might",
  "could",
  "possibly",
  "perhaps",
  "potentially",
  "somewhat",
  "kinda",
  "sorta",
  "soon",
  "eventually",
  "imho",
  "prob",
];

function containsHedging(text: string): boolean {
  const lower = text.toLowerCase();
  const words = lower.split(/\s+/);
  return words.some((w) =>
    HEDGING_WORDS.includes(w.replace(/[.,!?;:]$/, ""))
  );
}

/**
 * Verb detection. Catches obvious non-propositions like "Bullish on BTC" while
 * accepting real trading theses like "BTC closes above 120k".
 *
 * Strategy: require either a modal verb ("will close"), a copula ("is above"),
 * or one of an explicit set of trading-relevant action verbs. We do NOT accept
 * "any word ending in -s" because that matches "cuts" in "Bullish Fed cuts yay"
 * — a noun phrase pretending to be a thesis.
 */
function hasVerb(text: string): boolean {
  const lower = text.toLowerCase();
  const verbPatterns = [
    // Copulas and modals — true verbs
    /\b(is|are|was|were|be|been|being)\s+\w/,
    /\b(will|shall|may|must|should|would)\s+\w/,
    // Explicit trading action verbs (inflected forms)
    /\b(closes?|opens?|breaks?|holds?|rallies?|drops?|rises?|falls?|strikes?|resolves?|cuts?|raises?|hits?|exceeds?|crosses?|reaches?|meets?|beats?|misses?|trades?|settles?|liquidates?|retests?|pumps?|dumps?|moons?|breaches?|tests?)\b/,
    // Explicit announcement / confirmation verbs
    /\b(announce[sd]?|confirm[sd]?|reports?|reported|den(?:y|ies|ied)|reaches?|reached)\b/,
  ];
  const hit = verbPatterns.some((p) => p.test(lower));
  if (!hit) return false;
  // Reject propositions that start with adjectives like "Bullish" — these are
  // stance declarations, not tradable claims.
  const startsWithStance = /^\s*(bullish|bearish|neutral|long|short)\b/i.test(
    text
  );
  if (startsWithStance) {
    // Only accept if there's an explicit subject-verb structure after
    return /\b(is|are|will|should|closes?|breaks?|holds?)\b/.test(lower);
  }
  return true;
}

// ============================================================================
// Parse result
// ============================================================================

export interface ParseResult {
  success: boolean;
  thesis?: StructuredThesis;
  errors?: Array<{
    path: string;
    message: string;
    code: string; // Maps to REVIEW finding codes
  }>;
}

/**
 * Parse and validate a thesis. Parse failures return structured errors that
 * map to REVIEW findings — they never trigger payment.
 */
export function parseThesis(raw: unknown): ParseResult {
  const result = StructuredThesisSchema.safeParse(raw);
  if (result.success) {
    return { success: true, thesis: result.data };
  }

  const errors = result.error.issues.map((issue) => ({
    path: issue.path.join("."),
    message: issue.message,
    code: errorToReviewCode(issue.path.join("."), issue.message),
  }));

  return { success: false, errors };
}

function errorToReviewCode(path: string, message: string): string {
  if (path === "proposition") return "PARSE_FAILURE_PROPOSITION";
  if (path === "target_outcome") return "PARSE_FAILURE_TARGET_OUTCOME";
  if (path === "deadline") return "PARSE_FAILURE_DEADLINE";
  if (path.startsWith("market")) return "PARSE_FAILURE_MARKET";
  if (path.startsWith("proposed_trade")) return "PARSE_FAILURE_TRADE";
  if (path.startsWith("perp_context")) return "PARSE_FAILURE_PERP_CONTEXT";
  if (path.startsWith("evidence_claims")) return "PARSE_FAILURE_EVIDENCE";
  return "PARSE_FAILURE_GENERIC";
}
