// tests/coinglass.test.ts
import { describe, it, expect } from "vitest";
import { CoinGlassAdapter } from "../src/adapters/coinglass.js";

function mockResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });
}

describe("CoinGlassAdapter", () => {
  it("rejects construction without an API key", () => {
    expect(() => new CoinGlassAdapter({ apiKey: "" })).toThrow();
  });

  it("sends CG-API-KEY header on requests", async () => {
    let capturedHeaders: HeadersInit | undefined;
    const fakeFetch: typeof fetch = async (_url, init) => {
      capturedHeaders = init?.headers;
      return mockResponse({
        code: 0,
        data: [
          {
            exchange: "Binance",
            fundingRate: "0.0001",
            nextFundingTime: "2026-04-21T20:00:00Z",
            fundingInterval: 8,
          },
        ],
      });
    };
    const adapter = new CoinGlassAdapter({
      apiKey: "test-key-abcdef",
      fetchImpl: fakeFetch,
    });
    await adapter.getFundingRateByExchange("BTC");
    const h = capturedHeaders as Record<string, string>;
    expect(h["CG-API-KEY"]).toBe("test-key-abcdef");
  });

  it("normalizes funding rate response", async () => {
    const fakeFetch: typeof fetch = async () =>
      mockResponse({
        code: 0,
        data: [
          {
            exchange: "Binance",
            fundingRate: "0.00015",
            fundingInterval: 8,
          },
          {
            exchange: "Bybit",
            fundingRate: "-0.0002",
            fundingInterval: 8,
          },
        ],
      });
    const adapter = new CoinGlassAdapter({
      apiKey: "test-key-abcdef",
      fetchImpl: fakeFetch,
    });
    const result = await adapter.getFundingRateByExchange("BTC");
    expect(result).not.toBeNull();
    expect(result!.data.length).toBe(2);
    expect(result!.data[0].funding_rate).toBe(0.00015);
    expect(result!.data[1].funding_rate).toBe(-0.0002);
    expect(result!.source.provider).toBe("coinglass");
    expect(result!.source.response_hash).toMatch(/^[0-9a-f]{64}$/);
  });

  it("returns null on non-ok response", async () => {
    const fakeFetch: typeof fetch = async () => mockResponse({}, 500);
    const adapter = new CoinGlassAdapter({
      apiKey: "test-key-abcdef",
      fetchImpl: fakeFetch,
    });
    const result = await adapter.getFundingRateByExchange("BTC");
    expect(result).toBeNull();
  });

  it("returns null when CoinGlass signals error code", async () => {
    const fakeFetch: typeof fetch = async () =>
      mockResponse({ code: 40001, msg: "Invalid symbol" });
    const adapter = new CoinGlassAdapter({
      apiKey: "test-key-abcdef",
      fetchImpl: fakeFetch,
    });
    const result = await adapter.getFundingRateByExchange("UNKNOWN");
    expect(result).toBeNull();
  });

  it("caches responses within bucket window", async () => {
    let callCount = 0;
    const fakeFetch: typeof fetch = async () => {
      callCount++;
      return mockResponse({
        code: 0,
        data: [
          {
            exchange: "Binance",
            fundingRate: "0.0001",
            fundingInterval: 8,
          },
        ],
      });
    };
    const adapter = new CoinGlassAdapter({
      apiKey: "test-key-abcdef",
      fetchImpl: fakeFetch,
      cacheBucketSeconds: 300,
    });
    await adapter.getFundingRateByExchange("BTC");
    await adapter.getFundingRateByExchange("BTC");
    await adapter.getFundingRateByExchange("BTC");
    expect(callCount).toBe(1);
  });

  it("getPerpState combines funding + OI + liquidation sources", async () => {
    const fakeFetch: typeof fetch = async (url) => {
      const s = String(url);
      if (s.includes("fundingRate/exchange-list")) {
        return mockResponse({
          code: 0,
          data: [
            { exchange: "Binance", fundingRate: "0.0001", fundingInterval: 8 },
            { exchange: "Bybit", fundingRate: "0.00012", fundingInterval: 8 },
          ],
        });
      }
      if (s.includes("openInterest/exchange-list")) {
        return mockResponse({
          code: 0,
          data: [
            {
              exchange: "Binance",
              openInterestUsd: "1000000000",
              openInterestQuantity: "9500",
            },
            {
              exchange: "Bybit",
              openInterestUsd: "500000000",
              openInterestQuantity: "4700",
            },
          ],
        });
      }
      if (s.includes("liquidation/aggregated-history")) {
        return mockResponse({
          code: 0,
          data: {
            longLiquidationUsd: "50000000",
            shortLiquidationUsd: "30000000",
            liquidationMap: [
              { price: 99000, liquidationUsd: "8000000" },
              { price: 95000, liquidationUsd: "3000000" },
            ],
          },
        });
      }
      return mockResponse({ code: 0, data: [] });
    };
    const adapter = new CoinGlassAdapter({
      apiKey: "test-key-abcdef",
      fetchImpl: fakeFetch,
    });
    const result = await adapter.getPerpState("BTC");
    expect(result).not.toBeNull();
    expect(result!.state.open_interest_usd).toBe(1_500_000_000);
    // OI-weighted funding: (0.0001 * 1B + 0.00012 * 0.5B) / 1.5B
    expect(result!.state.current_funding_rate_8h).toBeCloseTo(0.00010667, 6);
    expect(result!.state.nearest_liquidation_cluster).toBeDefined();
    expect(result!.state.nearest_liquidation_cluster!.price).toBe(99000);
    expect(result!.sources.length).toBe(3);
    expect(result!.sources.every((s) => s.provider === "coinglass")).toBe(true);
  });
});
