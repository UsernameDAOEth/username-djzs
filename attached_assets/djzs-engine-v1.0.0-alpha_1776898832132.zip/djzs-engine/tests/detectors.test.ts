// tests/detectors.test.ts
import { describe, it, expect } from "vitest";
import { parseThesis } from "../src/schema/thesis.js";
import {
  X01_Detector,
  U03_Detector,
  R01_Detector,
  R02_Detector,
} from "../src/codes/detectors/index.js";
import type { EngineInput } from "../src/engine/core.js";

const basePM = {
  schema_version: "thesis-v1",
  submitted_at: "2026-04-21T12:00:00Z",
  proposition: "The Fed cuts rates by 25bps at the May 2026 FOMC meeting.",
  target_outcome: "Polymarket market resolves YES",
  deadline: "2026-05-15T23:59:59Z",
  market: {
    venue: "polymarket" as const,
    market_id: "0x123",
    market_url: "https://polymarket.com/event/fed",
  },
  proposed_trade: {
    direction: "yes" as const,
    size_usdc: 500,
    confidence: 0.65,
  },
  information_source_type: "public" as const,
  falsification_condition:
    "If April CPI exceeds 3.2% YoY the thesis is invalidated.",
};

const basePerp = {
  schema_version: "thesis-v1",
  submitted_at: "2026-04-21T12:00:00Z",
  proposition: "BTC-PERP closes above $110k within 7 days.",
  target_outcome: "BTC-PERP mark above 110000 at deadline",
  deadline: "2026-04-28T12:00:00Z", // 7 days = 21 funding intervals
  market: {
    venue: "hyperliquid" as const,
    market_id: "BTC",
    market_url: "https://app.hyperliquid.xyz/trade/BTC",
  },
  proposed_trade: {
    direction: "long" as const,
    size_usdc: 2000,
    confidence: 0.55,
    entry_price: 103500,
    target_price: 110000,
    stop_price: 100000,
    leverage: 3,
  },
  perp_context: {
    pair: "BTC-PERP",
    current_funding_rate_8h: 0.0001,
    oracle_price: 103500,
  },
  information_source_type: "public" as const,
  falsification_condition:
    "If BTC closes below $100k for two consecutive daily candles, invalidated.",
};

// ============================================================================
// X01 — EXECUTION_UNBOUND
// ============================================================================

describe("X01 EXECUTION_UNBOUND", () => {
  const detector = new X01_Detector();

  it("does not fire with conservative size + normal spread", () => {
    const thesis = parseThesis(basePM).thesis!;
    const input: EngineInput = {
      thesis,
      marketState: {
        current_price: 0.5,
        liquidity_depth_usdc: 100000,
        spread_bps: 50,
        fetched_at: "2026-04-21T12:00:00Z",
        source_response_hash: "test",
      },
    };
    expect(detector.detect(input)).toBeNull();
  });

  it("fires CRITICAL when size exceeds 10% of liquidity", () => {
    const thesis = parseThesis({
      ...basePM,
      proposed_trade: { ...basePM.proposed_trade, size_usdc: 20000 },
    }).thesis!;
    const input: EngineInput = {
      thesis,
      marketState: {
        current_price: 0.5,
        liquidity_depth_usdc: 100000,
        spread_bps: 50,
        fetched_at: "2026-04-21T12:00:00Z",
        source_response_hash: "test",
      },
    };
    const trigger = detector.detect(input);
    expect(trigger).not.toBeNull();
    expect(trigger!.severity).toBe("critical");
    expect(trigger!.reason).toContain("10% of liquidity");
  });

  it("fires on wide spread", () => {
    const thesis = parseThesis(basePM).thesis!;
    const input: EngineInput = {
      thesis,
      marketState: {
        current_price: 0.5,
        liquidity_depth_usdc: 100000,
        spread_bps: 500, // 5% spread
        fetched_at: "2026-04-21T12:00:00Z",
        source_response_hash: "test",
      },
    };
    const trigger = detector.detect(input);
    expect(trigger).not.toBeNull();
  });

  it("fires on leverage inconsistent with confidence", () => {
    const thesis = parseThesis({
      ...basePerp,
      proposed_trade: { ...basePerp.proposed_trade, leverage: 20, confidence: 0.5 },
    }).thesis!;
    const input: EngineInput = { thesis };
    const trigger = detector.detect(input);
    expect(trigger).not.toBeNull();
    expect(trigger!.severity).toBe("critical");
  });

  it("no fire without market state", () => {
    const thesis = parseThesis(basePM).thesis!;
    const input: EngineInput = { thesis };
    expect(detector.detect(input)).toBeNull();
  });
});

// ============================================================================
// U03 — UNFALSIFIABLE
// ============================================================================

describe("U03 UNFALSIFIABLE", () => {
  const detector = new U03_Detector();

  it("fires when falsification_condition is missing", () => {
    const { falsification_condition, ...minus } = basePM;
    const thesis = parseThesis(minus).thesis!;
    const input: EngineInput = { thesis };
    const trigger = detector.detect(input);
    expect(trigger).not.toBeNull();
    expect(trigger!.code).toBe("U03");
  });

  it("fires on vacuous condition", () => {
    const thesis = parseThesis({
      ...basePM,
      falsification_condition: "If things don't happen",
    }).thesis!;
    const trigger = detector.detect({ thesis });
    expect(trigger).not.toBeNull();
    expect(trigger!.reason).toContain("vacuous");
  });

  it("fires on tautological condition", () => {
    const thesis = parseThesis({
      ...basePM,
      falsification_condition: "The market resolves NO",
    }).thesis!;
    const trigger = detector.detect({ thesis });
    expect(trigger).not.toBeNull();
  });

  it("does not fire on specific observable condition", () => {
    const thesis = parseThesis(basePM).thesis!;
    const trigger = detector.detect({ thesis });
    expect(trigger).toBeNull();
  });
});

// ============================================================================
// R02 — FUNDING_DECAY
// ============================================================================

describe("R02 FUNDING_DECAY", () => {
  const detector = new R02_Detector();

  it("does not fire for non-perp venues", () => {
    const thesis = parseThesis(basePM).thesis!;
    const input: EngineInput = {
      thesis,
      perpState: {
        oracle_price: 100000,
        current_funding_rate_8h: 0.01,
      },
    };
    expect(detector.detect(input)).toBeNull();
  });

  it("does not fire when trader receives funding (short with positive funding)", () => {
    const thesis = parseThesis({
      ...basePerp,
      proposed_trade: {
        ...basePerp.proposed_trade,
        direction: "short" as const,
        entry_price: 103500,
        target_price: 95000,
      },
    }).thesis!;
    const input: EngineInput = {
      thesis,
      perpState: {
        oracle_price: 103500,
        current_funding_rate_8h: 0.0005, // shorts receive
      },
    };
    expect(detector.detect(input)).toBeNull();
  });

  it("fires when funding consumes >25% of edge", () => {
    // Long, high funding, small target move
    // Move: 0.5% (from 103500 → 104000), confidence 0.5 → edge 0.25%
    // Funding: 0.05% per 8h * 21 intervals = 1.05% → 4.2x edge → CRITICAL
    const thesis = parseThesis({
      ...basePerp,
      proposed_trade: {
        ...basePerp.proposed_trade,
        entry_price: 103500,
        target_price: 104000,
        confidence: 0.5,
      },
    }).thesis!;
    const input: EngineInput = {
      thesis,
      perpState: {
        oracle_price: 103500,
        current_funding_rate_8h: 0.0005,
      },
    };
    const trigger = detector.detect(input);
    expect(trigger).not.toBeNull();
    expect(trigger!.severity).toBe("critical");
  });

  it("fires MEDIUM when funding consumes 25-50% of edge", () => {
    // Need funding to be ~30% of implied edge
    // confidence 0.6, move 5% → edge 3%
    // Funding should be ~0.9% total → 0.043% per 8h over 21 intervals
    const thesis = parseThesis({
      ...basePerp,
      proposed_trade: {
        ...basePerp.proposed_trade,
        entry_price: 100000,
        target_price: 105000,
        confidence: 0.6,
      },
    }).thesis!;
    const input: EngineInput = {
      thesis,
      perpState: {
        oracle_price: 100000,
        current_funding_rate_8h: 0.00043, // ~0.9% over 21 intervals
      },
    };
    const trigger = detector.detect(input);
    expect(trigger).not.toBeNull();
    expect(["medium", "high"]).toContain(trigger!.severity);
  });

  it("does not fire when edge comfortably exceeds funding", () => {
    // Large target move, normal funding → funding is small % of edge
    const thesis = parseThesis({
      ...basePerp,
      proposed_trade: {
        ...basePerp.proposed_trade,
        entry_price: 100000,
        target_price: 150000, // 50% move
        confidence: 0.8, // edge = 40%
      },
    }).thesis!;
    const input: EngineInput = {
      thesis,
      perpState: {
        oracle_price: 100000,
        current_funding_rate_8h: 0.0001, // ~0.21% over 21 intervals
      },
    };
    expect(detector.detect(input)).toBeNull();
  });
});

// ============================================================================
// R01 — REFLEXIVITY_RISK
// ============================================================================

describe("R01 REFLEXIVITY_RISK", () => {
  const detector = new R01_Detector();

  it("does not fire for non-perp venues", () => {
    const thesis = parseThesis(basePM).thesis!;
    const input: EngineInput = {
      thesis,
      perpState: {
        oracle_price: 100000,
        current_funding_rate_8h: 0,
        nearest_liquidation_cluster: {
          price: 99000,
          distance_pct: 0.01,
          upstream_depth_usd: 0,
          at_cluster_depth_usd: 5_000_000,
        },
      },
    };
    expect(detector.detect(input)).toBeNull();
  });

  it("does not fire when stop is far from cluster", () => {
    const thesis = parseThesis(basePerp).thesis!;
    const input: EngineInput = {
      thesis,
      perpState: {
        oracle_price: 103500,
        current_funding_rate_8h: 0.0001,
        nearest_liquidation_cluster: {
          price: 90000, // stop at 100000, cluster at 90000 → 10% away
          distance_pct: 0.13,
          upstream_depth_usd: 0,
          at_cluster_depth_usd: 5_000_000,
        },
      },
    };
    expect(detector.detect(input)).toBeNull();
  });

  it("fires CRITICAL when stop is within 0.5% of large cluster", () => {
    const thesis = parseThesis({
      ...basePerp,
      proposed_trade: { ...basePerp.proposed_trade, stop_price: 100000 },
    }).thesis!;
    const input: EngineInput = {
      thesis,
      perpState: {
        oracle_price: 103500,
        current_funding_rate_8h: 0.0001,
        nearest_liquidation_cluster: {
          price: 100300, // 0.3% from stop
          distance_pct: 0.031,
          upstream_depth_usd: 0,
          at_cluster_depth_usd: 5_000_000, // $5M — large
        },
      },
    };
    const trigger = detector.detect(input);
    expect(trigger).not.toBeNull();
    expect(trigger!.severity).toBe("critical");
    expect(trigger!.reason).toContain("cascade liquidations");
  });

  it("fires HIGH when stop within 1% of cluster", () => {
    const thesis = parseThesis({
      ...basePerp,
      proposed_trade: { ...basePerp.proposed_trade, stop_price: 100000 },
    }).thesis!;
    const input: EngineInput = {
      thesis,
      perpState: {
        oracle_price: 103500,
        current_funding_rate_8h: 0.0001,
        nearest_liquidation_cluster: {
          price: 100800, // 0.8% from stop
          distance_pct: 0.025,
          upstream_depth_usd: 0,
          at_cluster_depth_usd: 2_000_000,
        },
      },
    };
    const trigger = detector.detect(input);
    expect(trigger).not.toBeNull();
    expect(trigger!.severity).toBe("high");
  });

  it("does not fire without stop_price", () => {
    const { stop_price, ...tradeWithoutStop } = basePerp.proposed_trade;
    const thesis = parseThesis({
      ...basePerp,
      proposed_trade: tradeWithoutStop,
    }).thesis!;
    const input: EngineInput = {
      thesis,
      perpState: {
        oracle_price: 103500,
        current_funding_rate_8h: 0.0001,
        nearest_liquidation_cluster: {
          price: 103400,
          distance_pct: 0.001,
          upstream_depth_usd: 0,
          at_cluster_depth_usd: 5_000_000,
        },
      },
    };
    expect(detector.detect(input)).toBeNull();
  });
});
