// tests/engine.test.ts
import { describe, it, expect } from "vitest";
import {
  computeVerdict,
  canonicalJSON,
  hashInput,
  keccak256,
  type EngineInput,
} from "../src/engine/core.js";
import { defaultDetectors } from "../src/codes/detectors/index.js";
import { parseThesis } from "../src/schema/thesis.js";

const validPMThesis = {
  schema_version: "thesis-v1",
  submitted_at: "2026-04-21T12:00:00Z",
  proposition: "The Fed cuts rates by 25bps at the May 2026 FOMC meeting.",
  target_outcome: "Polymarket market 'Fed cut May 2026' resolves YES",
  deadline: "2026-05-15T23:59:59Z",
  market: {
    venue: "polymarket",
    market_id: "0x123",
    market_url: "https://polymarket.com/event/fed-cut-may",
  },
  proposed_trade: {
    direction: "yes",
    size_usdc: 500,
    confidence: 0.65,
  },
  information_source_type: "public",
  key_assumptions: ["Fed holds dovish guidance"],
  evidence_claims: [],
  falsification_condition:
    "If the April CPI print comes in above 3.2% YoY, the thesis is invalidated.",
};

describe("canonicalJSON", () => {
  it("sorts object keys alphabetically", () => {
    expect(canonicalJSON({ b: 1, a: 2 })).toBe('{"a":2,"b":1}');
  });

  it("produces identical output for semantically equal objects", () => {
    const a = { z: 1, a: { y: 2, b: 3 } };
    const b = { a: { b: 3, y: 2 }, z: 1 };
    expect(canonicalJSON(a)).toBe(canonicalJSON(b));
  });

  it("handles arrays in order", () => {
    expect(canonicalJSON([3, 1, 2])).toBe("[3,1,2]");
  });

  it("handles nested structures", () => {
    expect(canonicalJSON({ a: [{ b: 1, a: 2 }] })).toBe('{"a":[{"a":2,"b":1}]}');
  });

  it("handles null and booleans", () => {
    expect(canonicalJSON({ a: null, b: true, c: false })).toBe(
      '{"a":null,"b":true,"c":false}'
    );
  });

  it("omits undefined values (matches JSON.stringify)", () => {
    // This is the critical invariant: canonicalJSON must produce the same
    // output before and after a JSON round-trip. Undefined keys disappear
    // after stringification, so they must also be omitted by canonicalJSON.
    const original = { a: "x", b: undefined, c: { d: "y" } };
    const roundTripped = JSON.parse(JSON.stringify(original));
    expect(canonicalJSON(original)).toBe(canonicalJSON(roundTripped));
  });

  it("round-trip invariant holds for nested undefined", () => {
    const original = {
      top: "x",
      nested: { inner: undefined, kept: "y" },
      also: undefined,
    };
    const roundTripped = JSON.parse(JSON.stringify(original));
    expect(canonicalJSON(original)).toBe(canonicalJSON(roundTripped));
  });
});

describe("hashInput", () => {
  it("produces deterministic hashes for equal inputs", () => {
    const a = { foo: "bar", n: 42 };
    const b = { n: 42, foo: "bar" };
    expect(hashInput(a)).toBe(hashInput(b));
  });

  it("produces different hashes for different inputs", () => {
    expect(hashInput({ a: 1 })).not.toBe(hashInput({ a: 2 }));
  });

  it("is 64 hex characters (256 bits)", () => {
    const h = hashInput({ a: 1 });
    expect(h).toMatch(/^[0-9a-f]{64}$/);
  });
});

describe("computeVerdict determinism", () => {
  it("returns identical verdict for identical inputs (modulo timestamp)", () => {
    const parsed = parseThesis(validPMThesis);
    expect(parsed.success).toBe(true);
    const input: EngineInput = { thesis: parsed.thesis! };
    const v1 = computeVerdict(input, defaultDetectors());
    const v2 = computeVerdict(input, defaultDetectors());

    expect(v1.verdict).toBe(v2.verdict);
    expect(v1.risk_score).toBe(v2.risk_score);
    expect(v1.triggered_codes.length).toBe(v2.triggered_codes.length);
    expect(v1.compute_hash).toBe(v2.compute_hash);
  });

  it("different inputs produce different compute hashes", () => {
    const parsedA = parseThesis(validPMThesis);
    const parsedB = parseThesis({
      ...validPMThesis,
      proposed_trade: { ...validPMThesis.proposed_trade, size_usdc: 5000 },
    });

    const vA = computeVerdict({ thesis: parsedA.thesis! }, defaultDetectors());
    const vB = computeVerdict({ thesis: parsedB.thesis! }, defaultDetectors());

    expect(vA.compute_hash).not.toBe(vB.compute_hash);
  });
});

describe("verdict thresholds", () => {
  it("PASS with no triggers", () => {
    const parsed = parseThesis(validPMThesis);
    const v = computeVerdict({ thesis: parsed.thesis! }, defaultDetectors());
    expect(v.risk_score).toBeLessThan(20);
    expect(v.verdict).toBe("PASS");
  });
});
