// tests/receipts.test.ts
import { describe, it, expect } from "vitest";
import { parseThesis } from "../src/schema/thesis.js";
import { computeVerdict } from "../src/engine/core.js";
import { defaultDetectors } from "../src/codes/detectors/index.js";
import {
  generateReceipt,
  verifyReceiptHash,
} from "../src/receipts/schema.js";

const thesis = {
  schema_version: "thesis-v1",
  submitted_at: "2026-04-21T12:00:00Z",
  proposition: "The Fed cuts rates by 25bps at the May 2026 FOMC meeting.",
  target_outcome: "Polymarket market resolves YES",
  deadline: "2026-05-15T23:59:59Z",
  market: {
    venue: "polymarket",
    market_id: "0x123",
    market_url: "https://polymarket.com/event/fed",
  },
  proposed_trade: {
    direction: "yes",
    size_usdc: 500,
    confidence: 0.65,
  },
  information_source_type: "public",
  falsification_condition: "If April CPI exceeds 3.2% YoY.",
};

describe("generateReceipt", () => {
  it("produces a receipt with valid keccak proof", () => {
    const parsed = parseThesis(thesis);
    const verdict = computeVerdict(
      { thesis: parsed.thesis! },
      defaultDetectors()
    );
    const receipt = generateReceipt({
      thesis: parsed.thesis!,
      verdict,
      audit_requested_at: "2026-04-21T12:00:00Z",
    });
    expect(receipt.keccak_proof).toMatch(/^[0-9a-f]{64}$/);
    expect(receipt.schema_version).toBe("receipt-v2");
    expect(receipt.receipt_id).toMatch(/^rcp_/);
  });

  it("receipt hash is verifiable", () => {
    const parsed = parseThesis(thesis);
    const verdict = computeVerdict(
      { thesis: parsed.thesis! },
      defaultDetectors()
    );
    const receipt = generateReceipt({
      thesis: parsed.thesis!,
      verdict,
      audit_requested_at: "2026-04-21T12:00:00Z",
    });
    const verification = verifyReceiptHash(receipt);
    expect(verification.valid).toBe(true);
  });

  it("tampered receipt fails verification", () => {
    const parsed = parseThesis(thesis);
    const verdict = computeVerdict(
      { thesis: parsed.thesis! },
      defaultDetectors()
    );
    const receipt = generateReceipt({
      thesis: parsed.thesis!,
      verdict,
      audit_requested_at: "2026-04-21T12:00:00Z",
    });
    // Tamper
    receipt.risk_score = receipt.risk_score + 100;
    const verification = verifyReceiptHash(receipt);
    expect(verification.valid).toBe(false);
  });

  it("includes standard disclaimers on every receipt", () => {
    const parsed = parseThesis(thesis);
    const verdict = computeVerdict(
      { thesis: parsed.thesis! },
      defaultDetectors()
    );
    const receipt = generateReceipt({
      thesis: parsed.thesis!,
      verdict,
      audit_requested_at: "2026-04-21T12:00:00Z",
    });
    expect(receipt.disclaimers.pass_does_not_guarantee_resolution).toContain(
      "DJZS audit"
    );
  });

  it("includes perp disclaimer for hyperliquid venues", () => {
    const perpThesis = {
      ...thesis,
      proposition: "BTC-PERP closes above 110k within 7 days.",
      market: {
        venue: "hyperliquid",
        market_id: "BTC",
        market_url: "https://app.hyperliquid.xyz/trade/BTC",
      },
      proposed_trade: {
        direction: "long",
        size_usdc: 2000,
        confidence: 0.55,
        entry_price: 103500,
        target_price: 110000,
      },
      perp_context: {
        pair: "BTC-PERP",
        current_funding_rate_8h: 0.0001,
        oracle_price: 103500,
      },
    };
    const parsed = parseThesis(perpThesis);
    expect(parsed.success).toBe(true);
    const verdict = computeVerdict(
      { thesis: parsed.thesis! },
      defaultDetectors()
    );
    const receipt = generateReceipt({
      thesis: parsed.thesis!,
      verdict,
      audit_requested_at: "2026-04-21T12:00:00Z",
    });
    expect(receipt.disclaimers.perp_pre_trade_only).toBeDefined();
  });

  it("includes MNPI disclaimer when source is private", () => {
    const privateThesis = { ...thesis, information_source_type: "private" };
    const parsed = parseThesis(privateThesis);
    const verdict = computeVerdict(
      { thesis: parsed.thesis! },
      defaultDetectors()
    );
    const receipt = generateReceipt({
      thesis: parsed.thesis!,
      verdict,
      audit_requested_at: "2026-04-21T12:00:00Z",
    });
    expect(receipt.disclaimers.mnpi_recorded).toBeDefined();
  });
});
