// tests/schema.test.ts
import { describe, it, expect } from "vitest";
import { parseThesis } from "../src/schema/thesis.js";

const validPM = {
  schema_version: "thesis-v1",
  submitted_at: "2026-04-21T12:00:00Z",
  proposition: "The Fed cuts rates by 25bps at the May 2026 FOMC meeting.",
  target_outcome: "Polymarket market resolves YES",
  deadline: "2026-05-15T23:59:59Z",
  market: {
    venue: "polymarket",
    market_id: "0x123",
    market_url: "https://polymarket.com/event/fed",
  },
  proposed_trade: {
    direction: "yes",
    size_usdc: 500,
    confidence: 0.65,
  },
  information_source_type: "public",
};

describe("parseThesis — valid inputs", () => {
  it("parses a clean PM thesis", () => {
    const result = parseThesis(validPM);
    expect(result.success).toBe(true);
    expect(result.thesis).toBeDefined();
  });

  it("fills default empty arrays for optional lists", () => {
    const result = parseThesis(validPM);
    expect(result.thesis!.key_assumptions).toEqual([]);
    expect(result.thesis!.evidence_claims).toEqual([]);
  });
});

describe("parseThesis — proposition validation", () => {
  it("rejects questions", () => {
    const result = parseThesis({
      ...validPM,
      proposition: "Will the Fed cut rates in May?",
    });
    expect(result.success).toBe(false);
    expect(result.errors?.some((e) => e.path === "proposition")).toBe(true);
  });

  it("rejects hedging language", () => {
    const result = parseThesis({
      ...validPM,
      proposition: "The Fed might maybe probably cut rates soon.",
    });
    expect(result.success).toBe(false);
  });

  it("rejects no-verb propositions", () => {
    const result = parseThesis({
      ...validPM,
      proposition: "Bullish Fed cuts yay amazing",
    });
    // Won't have a verb pattern — should fail
    expect(result.success).toBe(false);
  });

  it("rejects too-short propositions", () => {
    const result = parseThesis({ ...validPM, proposition: "Fed cut" });
    expect(result.success).toBe(false);
  });
});

describe("parseThesis — deadline validation", () => {
  it("rejects deadline before submission", () => {
    const result = parseThesis({
      ...validPM,
      submitted_at: "2026-05-01T00:00:00Z",
      deadline: "2026-04-01T00:00:00Z",
    });
    expect(result.success).toBe(false);
  });
});

describe("parseThesis — venue consistency", () => {
  it("requires perp_context for hyperliquid", () => {
    const result = parseThesis({
      ...validPM,
      market: {
        venue: "hyperliquid",
        market_id: "BTC",
        market_url: "https://app.hyperliquid.xyz/trade/BTC",
      },
      proposed_trade: {
        direction: "long",
        size_usdc: 1000,
        confidence: 0.6,
      },
      // no perp_context
    });
    expect(result.success).toBe(false);
    expect(
      result.errors?.some((e) => e.path === "perp_context")
    ).toBe(true);
  });

  it("requires long/short for hyperliquid, not yes/no", () => {
    const result = parseThesis({
      ...validPM,
      market: {
        venue: "hyperliquid",
        market_id: "BTC",
        market_url: "https://app.hyperliquid.xyz/trade/BTC",
      },
      proposed_trade: {
        direction: "yes", // wrong for perp
        size_usdc: 1000,
        confidence: 0.6,
      },
      perp_context: {
        pair: "BTC-PERP",
        current_funding_rate_8h: 0.0001,
        oracle_price: 100000,
      },
    });
    expect(result.success).toBe(false);
  });

  it("accepts valid perp thesis", () => {
    const result = parseThesis({
      schema_version: "thesis-v1",
      submitted_at: "2026-04-21T12:00:00Z",
      proposition: "BTC-PERP closes above $110k within 7 days.",
      target_outcome: "BTC-PERP mark price above 110000 at deadline",
      deadline: "2026-04-28T23:59:59Z",
      market: {
        venue: "hyperliquid",
        market_id: "BTC",
        market_url: "https://app.hyperliquid.xyz/trade/BTC",
      },
      proposed_trade: {
        direction: "long",
        size_usdc: 2000,
        confidence: 0.55,
        entry_price: 103500,
        target_price: 110000,
        stop_price: 100000,
        leverage: 3,
      },
      perp_context: {
        pair: "BTC-PERP",
        current_funding_rate_8h: 0.0001,
        oracle_price: 103500,
      },
      information_source_type: "public",
    });
    expect(result.success).toBe(true);
  });
});

describe("parseThesis — error codes", () => {
  it("maps proposition errors to PARSE_FAILURE_PROPOSITION", () => {
    const result = parseThesis({ ...validPM, proposition: "???" });
    expect(result.success).toBe(false);
    expect(
      result.errors?.some((e) => e.code === "PARSE_FAILURE_PROPOSITION")
    ).toBe(true);
  });
});
