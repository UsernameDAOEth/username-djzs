import { getIrysUploader } from "./irys.js";
function normalizeUsername(u){return String(u||"").trim().toLowerCase().replace(/[^a-z0-9_\-\.]/g,"");}
export function buildAgentCore({username,ownerWallet,storageMode="LOCAL_IRYS"}){
 const n=normalizeUsername(username); if(!n) throw new Error("Invalid username");
 const agentId=`agent_${n}_${Date.now()}`;
 return {username:n,agentId,ownerWallet:ownerWallet||null,createdAt:new Date().toISOString(),
  protocolVersion:"DJZS-0.1",storage:{mode:storageMode,irysEnabled:true},zones:[1,2,3,4,5,6,7,8,9,10],
  config:{journalingStyle:"problem-solution-usecases"}};
}
export async function saveAgentCoreToIrys(agentCore){
 const u=await getIrysUploader();
 const data=JSON.stringify(agentCore,null,2);
 const tags=[{name:"protocol",value:"DJZS"},{name:"protocol-version",value:"DJZS-0.1"},
 {name:"type",value:"agent-core"},{name:"username",value:String(agentCore.username)}];
 const r=await u.upload(data,{tags});
 return {irysId:r.id,irysUrl:`https://gateway.irys.xyz/${r.id}`};
}
export function buildUsernameNftMetadata({username,agentCoreIrysId,imageUrl,externalUrl}){
 const n=normalizeUsername(username);
 return {name:`@${n}`,description:`DJZS Identity NFT for @${n}`,image:imageUrl||"",external_url:externalUrl||"",
 attributes:[{trait_type:"Protocol",value:"DJZS"}],agent_core_irys_id:agentCoreIrysId};
}