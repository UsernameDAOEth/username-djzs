import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import { saveJournalToIrys } from "./journal.js";
import { buildAgentCore, saveAgentCoreToIrys, buildUsernameNftMetadata } from "./agent.js";
dotenv.config();
const app=express(); const PORT=process.env.PORT||3000;
const __filename=fileURLToPath(import.meta.url);
const __dirname=path.dirname(__filename);
const publicDir=path.join(__dirname,"public");
app.use(cors()); app.use(express.json({limit:"1mb"})); app.use(express.static(publicDir));
app.get("/",(req,res)=>res.sendFile(path.join(publicDir,"index.html")));
app.post("/api/journal/finalize", async (req,res)=>{
 try{ const r=await saveJournalToIrys(req.body); res.json({ok:true,...r});}
 catch(e){res.json({ok:false,error:e.message});}});
app.post("/api/agent/activate", async (req,res)=>{
 try{
  const {username,ownerWallet,storageMode}=req.body;
  const agentCore=buildAgentCore({username,ownerWallet,storageMode});
  const {irysId,irysUrl}=await saveAgentCoreToIrys(agentCore);
  const meta=buildUsernameNftMetadata({username:agentCore.username,agentCoreIrysId:irysId});
  res.json({ok:true,agentCore,irysId,irysUrl,nftMetadata:meta});
 }catch(e){res.json({ok:false,error:e.message});}});
app.listen(PORT,()=>console.log("DJZS bundle running on "+PORT));
