import { Uploader } from "@irys/upload";
import { BaseETH } from "@irys/upload-base";
import dotenv from "dotenv"; dotenv.config();
const { PRIVATE_KEY } = process.env;
export const getIrysUploader = async () => {
  if (!PRIVATE_KEY) throw new Error("Missing PRIVATE_KEY");
  return await Uploader(BaseETH).withWallet(PRIVATE_KEY);
};