import { getIrysUploader } from "./irys.js";
export async function saveJournalToIrys(p){
 const req=["title","content","zoneId","zoneSlug","timeCode","createdAt","version"];
 for(const k of req){ if(p[k]==null) throw new Error("Missing "+k);}
 const u=await getIrysUploader();
 const data=JSON.stringify(p,null,2);
 const tags=[{name:"protocol",value:"DJZS"},{name:"protocol-version",value:"DJZS-0.1"},
 {name:"zone-id",value:String(p.zoneId)},{name:"zone-slug",value:String(p.zoneSlug)},
 {name:"time-code",value:String(p.timeCode)},{name:"version",value:String(p.version)}];
 const r=await u.upload(data,{tags});
 return {irysId:r.id,irysUrl:`https://gateway.irys.xyz/${r.id}`};
}