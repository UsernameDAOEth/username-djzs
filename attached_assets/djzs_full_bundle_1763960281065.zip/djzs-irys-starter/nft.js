import { ethers } from "ethers";
import dotenv from "dotenv"; dotenv.config();
const { PRIVATE_KEY, RPC_URL, NFT_CONTRACT_ADDRESS } = process.env;
const ABI=["function mintUsername(address to, string username, string tokenURI) external returns (uint256)"];
export function getNftContract(){
 if(!PRIVATE_KEY) throw new Error("Missing_PRIVATE_KEY");
 if(!RPC_URL) throw new Error("Missing_RPC_URL");
 if(!NFT_CONTRACT_ADDRESS) throw new Error("Missing_NFT_CONTRACT_ADDRESS");
 const provider=new ethers.JsonRpcProvider(RPC_URL);
 const wallet=new ethers.Wallet(PRIVATE_KEY,provider);
 return new ethers.Contract(NFT_CONTRACT_ADDRESS,ABI,wallet);
}